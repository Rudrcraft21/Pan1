<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PANYATRA - Booking </title>
    <?php require('inc/link.php'); ?>
    <style>
        body {
            background: #f9f9f9;
            font-family: 'Roboto', sans-serif;
        }

        .navbar {
            border-radius: 10px;
        }

        .card {
            border: none;
            border-radius: 10px;
        }

        .custom-bg {
            background-color: #ffaa16;
        }

        .custom-bg:hover {
            background-color: #ff9a00;
        }

        .filter-header {
            font-size: 20px;
            font-weight: bold;
            color: #ffaa16;
        }

        .dropdown-scroll {
            max-height: 300px;
            overflow-y: auto;
        }

        .badge {
            font-size: 12px;
        }

        .btn-custom {
            background-color: #ffaa16;
            color: white;
            border: none;
        }

        .btn-custom:hover {
            background-color: #ff9a00;
        }

        .btn-outline-custom {
            color: #ffaa16;
            border: 1px solid #ffaa16;
        }

        .btn-outline-custom:hover {
            background-color: #ffaa16;
            color: white;
        }
    </style>
</head>

<body>

    <!-- Header Section -->
    <?php require('inc/header.php'); ?>

    <!-- Blog Title Section -->
    <div class="my-5 px-4 text-center">
        <h2 class="fw-bold h-font">Explore PanYatra</h2>
        <div class="h-line bg-warning"></div>
    </div>

    <!-- Filters and Cards Section -->
    <div class="container">
        <div class="row">
            <!-- Filters Section -->
            <div class="col-lg-3 col-md-12 mb-lg-0 mb-4">
                <div class="bg-white p-4 rounded shadow-sm">
                    <h4 class="filter-header">Filters</h4>
                    <hr>

                    <!-- Booking Type -->
                    <h6>Booking Type</h6>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="bookingType" id="packages" value="packages" checked onclick="updateFilters('packages')">
                        <label class="form-check-label" for="packages">Packages</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="bookingType" id="cab" value="cab" onclick="updateFilters('cab')">
                        <label class="form-check-label" for="cab">Cab</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="bookingType" id="hotel" value="hotel" onclick="updateFilters('hotel')">
                        <label class="form-check-label" for="hotel">Hotel</label>
                    </div>
                    <hr>

                    <!-- Dynamic Filters will be loaded here -->
                    <div id="dynamicFilters">
                        <!-- Default filters for Packages -->
                        <div id="packageFilters">
                            <h6>Location Filters</h6>
                            <div>
                                <label for="selectedLocation" class="form-label">From Location</label>
                                <div class="btn-group w-100">
                                    <input type="text" class="form-control shadow-none" id="selectedLocation" placeholder="Select Location">
                                    <button type="button" class="btn btn-custom dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false"></button>
                                    <ul class="dropdown-menu dropdown-scroll" id="bookingFromDropdown"></ul>
                                </div>
                            </div>
                            <div class="mt-3">
                                <label for="selectedDestination" class="form-label">To Location</label>
                                <div class="btn-group w-100">
                                    <input type="text" class="form-control shadow-none" id="selectedDestination" placeholder="Select Location">
                                    <button type="button" class="btn btn-custom dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false"></button>
                                    <ul class="dropdown-menu dropdown-scroll" id="bookingToDropdown"></ul>
                                </div>
                            </div>
                            <hr>

                            <h6>Facilities</h6>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="facility1">
                                <label class="form-check-label" for="facility1">Air Conditioned</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="facility2">
                                <label class="form-check-label" for="facility2">Wi-Fi</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="facility3">
                                <label class="form-check-label" for="facility3">GPS Enabled</label>
                            </div>
                            <hr>
                        </div>

                        <!-- Default filters for Cab -->
                        <div id="cabFilters" style="display:none;">
                            <h6>Pick-up Location</h6>
                            <div>
                                <label for="pickUpLocation" class="form-label">From Location</label>
                                <input type="text" class="form-control shadow-none" id="pickUpLocation" placeholder="Select Pick-up Location">
                            </div>
                            <div class="mt-3">
                                <label for="dropLocation" class="form-label">To Location</label>
                                <input type="text" class="form-control shadow-none" id="dropLocation" placeholder="Select Drop Location">
                            </div>
                            <hr>

                            <h6>Facilities</h6>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="cabAC">
                                <label class="form-check-label" for="cabAC">Air Conditioned</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="cabWiFi">
                                <label class="form-check-label" for="cabWiFi">Wi-Fi</label>
                            </div>
                            <hr>
                        </div>

                        <!-- Default filters for Hotel -->
                        <div id="hotelFilters" style="display:none;">
                            <h6>Hotel Location</h6>
                            <div>
                                <label for="hotelLocation" class="form-label">Select Location</label>
                                <input type="text" class="form-control shadow-none" id="hotelLocation" placeholder="Select Hotel Location">
                            </div>
                            <div class="mt-3">
                                <label for="hotelRating" class="form-label">Rating</label>
                                <select class="form-select shadow-none" id="hotelRating">
                                    <option value="any">Any</option>
                                    <option value="1">1 Star</option>
                                    <option value="2">2 Stars</option>
                                    <option value="3">3 Stars</option>
                                    <option value="4">4 Stars</option>
                                    <option value="5">5 Stars</option>
                                </select>
                            </div>
                            <hr>

                            <h6>Amenities</h6>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="hotelAC">
                                <label class="form-check-label" for="hotelAC">Air Conditioned</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="hotelPool">
                                <label class="form-check-label" for="hotelPool">Swimming Pool</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="hotelBreakfast">
                                <label class="form-check-label" for="hotelBreakfast">Free Breakfast</label>
                            </div>
                            <hr>
                        </div>
                    </div>

                    <!-- Apply Filters Button -->
                    <button class="btn btn-custom w-100">Apply Filters</button>
                </div>
            </div>

            <!-- Cards Section -->
            <div class="col-lg-9 col-md-12">
                <!-- Card 1: Bus Service (Company 1) -->
                <div class="card mb-4 border-primary">
                    <div class="row g-0">
                        <div class="col-md-4">
                            <img src="image/travel1.jpg" class="img-fluid rounded-start" alt="Bus Service">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-primary">Luxury Bus Service - Horizon Travels</h5>
                                <p class="card-text">Enjoy a comfortable and secure ride with our top-notch bus services from Horizon Travels.</p>
                                <p class="card-text">
                                    <span class="badge bg-light text-dark">Wi-Fi</span>
                                    <span class="badge bg-light text-dark">AC</span>
                                    <span class="badge bg-light text-dark">GPS</span>
                                </p>
                                <a href="#" class="btn btn-primary btn-sm me-2">Book Now</a>
                                <a href="bus.php" class="btn btn-outline-primary btn-sm">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Card 2: Flight Service (Company 2) -->
                <div class="card mb-4 border-success">
                    <div class="row g-0">
                        <div class="col-md-4">
                            <img src="image/flight.jpg" class="img-fluid rounded-start" alt="Flight Service">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-success">First-Class Flight Experience - SkyHigh Airlines</h5>
                                <p class="card-text">Fly in style with SkyHigh Airlines. First-class services with premium comfort.</p>
                                <p class="card-text">
                                    <span class="badge bg-light text-dark">In-Flight Wi-Fi</span>
                                    <span class="badge bg-light text-dark">Meal Service</span>
                                    <span class="badge bg-light text-dark">VIP Lounge Access</span>
                                </p>
                                <a href="#" class="btn btn-success btn-sm me-2">Book Now</a>
                                <a href="airplane.php" class="btn btn-outline-success btn-sm">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Card 3: Train Service (Company 3) -->
                <div class="card mb-4 border-warning">
                    <div class="row g-0">
                        <div class="col-md-4">
                            <img src="image/train.jpg" class="img-fluid rounded-start" alt="Train Service">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-warning">Express Train Journeys - Royal Railways</h5>
                                <p class="card-text">Travel in comfort and speed with Royal Railways. Book your express train journey today.</p>
                                <p class="card-text">
                                    <span class="badge bg-light text-dark">Complimentary Meals</span>
                                    <span class="badge bg-light text-dark">Reclining Seats</span>
                                    <span class="badge bg-light text-dark">Scenic Views</span>
                                </p>
                                <a href="#" class="btn btn-warning btn-sm me-2">Book Now</a>
                                <a href="train.php" class="btn btn-outline-warning btn-sm">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Card 4: Cruise Service (Company 4) -->
                <div class="card mb-4 border-danger">
                    <div class="row g-0">
                        <div class="col-md-4">
                            <img src="image/cruise.jpg" class="img-fluid rounded-start" alt="Cruise Service">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-danger">Luxury Cruise - Oceanic Voyages</h5>
                                <p class="card-text">Set sail on a luxury cruise with Oceanic Voyages. Enjoy all-inclusive services while at sea.</p>
                                <p class="card-text">
                                    <span class="badge bg-light text-dark">All-Inclusive Dining</span>
                                    <span class="badge bg-light text-dark">Private Balcony</span>
                                    <span class="badge bg-light text-dark">Entertainment</span>
                                </p>
                                <a href="#" class="btn btn-danger btn-sm me-2">Book Now</a>
                                <a href="#" class="btn btn-outline-danger btn-sm">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Card 5: Cab Service (Company 5) -->
                <div class="card mb-4 border-info">
                    <div class="row g-0">
                        <div class="col-md-4">
                            <img src="image/taxi.jpg" class="img-fluid rounded-start" alt="Cab Service">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-info">Reliable Cab Service - FastTrack Cabs</h5>
                                <p class="card-text">Book a ride with FastTrack Cabs for quick and reliable taxi services across the city.</p>
                                <p class="card-text">
                                    <span class="badge bg-light text-dark">24/7 Availability</span>
                                    <span class="badge bg-light text-dark">Clean & Comfortable</span>
                                    <span class="badge bg-light text-dark">GPS Tracking</span>
                                </p>
                                <a href="#" class="btn btn-info btn-sm me-2">Book Now</a>
                                <a href="#" class="btn btn-outline-info btn-sm">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>

    <!-- Footer Section -->
    <?php require('inc/footer.php'); ?>

    <script>
        function updateFilters(type) {
            // Hide all filters by default
            document.getElementById('packageFilters').style.display = 'none';
            document.getElementById('cabFilters').style.display = 'none';
            document.getElementById('hotelFilters').style.display = 'none';

            // Show selected filters
            if (type === 'packages') {
                document.getElementById('packageFilters').style.display = 'block';
            } else if (type === 'cab') {
                document.getElementById('cabFilters').style.display = 'block';
            } else if (type === 'hotel') {
                document.getElementById('hotelFilters').style.display = 'block';
            }
        }

        // Call the function on page load to set the initial state
        updateFilters('packages');
    </script>

</body>

</html>