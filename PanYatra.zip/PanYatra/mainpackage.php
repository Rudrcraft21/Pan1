<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PANYATRA - Tour Packages</title>
    <?php require('inc/link.php'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<style>
    .btn-secondary {
        background-color: #f4a261;
        color: #fff;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        font-size: 1rem;
    }

    .btn-secondary:hover {
        background-color: #2a9d8f;
    }

    /* Aqua line for range input */
    input[type="range"]::-webkit-slider-runnable-track {
        background-color: #00c1c1;
        /* Aqua line color */
        height: 8px;
        border-radius: 4px;
        border: none;
    }

    input[type="range"]::-moz-range-track {
        background-color: #00c1c1;
        /* Aqua line color */
        height: 8px;
        border-radius: 4px;
        border: none;
    }

    /* Track styling */
    input[type="range"]::-webkit-slider-runnable-track {
        background-color: #00c1c1;
        /* Aqua line color */
        height: 8px;
        border-radius: 4px;
        border: none;
    }

    input[type="range"]::-moz-range-track {
        background-color: #00c1c1;
        /* Aqua line color */
        height: 8px;
        border-radius: 4px;
        border: none;
    }

    /* Thumb styling with rupee symbol */
    input[type="range"]::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        background-color: #ffaa16;
        /* Thumb color */
        border: 2px solid white;
        cursor: pointer;
        margin-top: -12px;
        /* Align thumb with track */
        position: relative;
    }

    input[type="range"]::-webkit-slider-thumb::before {
        content: "₹";
        font-size: 18px;
        color: white;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    input[type="range"]::-moz-range-thumb {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        background-color: #ffaa16;
        /* Thumb color */
        border: 2px solid white;
        cursor: pointer;
        position: relative;
    }

    input[type="range"]::-moz-range-thumb::before {
        content: "₹";
        font-size: 18px;
        color: white;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    /* Arrow indicators for Low and High */
    .slider-container {
        position: relative;
    }

    .slider-container::before,
    .slider-container::after {
        content: "";
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        width: 0;
        height: 0;
        border-style: solid;
    }

    .slider-container::before {
        left: -20px;
        border-width: 5px 6px 5px 0;
        border-color: transparent #00c1c1 transparent transparent;
    }

    .slider-container::after {
        right: -20px;
        border-width: 5px 0 5px 6px;
        border-color: transparent transparent transparent #00c1c1;
    }

    input[type="range"] {
        outline: none;
        width: 100%;
    }
</style>

<body class="bg-light">

    <!-- Header Section -->
    <?php require('inc/header.php'); ?>

    <!-- Packages Section -->
    <div class="container my-5">
        <h2 class="text-center mb-4 h-font fw-bold ">Explore Our Tour Packages</h2>
        <div class="row g-4">
            <!-- Package 1 -->
            <div class="col-md-4">
                <div class="card shadow h-100">
                    <img src="images/package1.jpg" class="card-img-top" alt="Shimla-Manali Package">
                    <div class="card-body">
                        <h5 class="card-title">Shimla-Manali Tour</h5>
                        <p class="card-text">Experience the best of the Himalayas with this 6-day package covering Shimla and Manali.</p>
                        <ul>
                            <li>Duration: 6 Days</li>
                            <li>Starting from: ₹25,000</li>
                        </ul>
                        <a href="#" class="btn btn-secondary">View Details</a>
                    </div>
                </div>
            </div>

            <!-- Package 2 -->
            <div class="col-md-4">
                <div class="card shadow h-100">
                    <img src="images/package2.jpg" class="card-img-top" alt="Manali-Kullu Package">
                    <div class="card-body">
                        <h5 class="card-title">Manali-Kullu Adventure</h5>
                        <p class="card-text">Explore Manali and Kullu Valley with thrilling adventure activities and serene views.</p>
                        <ul>
                            <li>Duration: 5 Days</li>
                            <li>Starting from: ₹22,000</li>
                        </ul>
                        <a href="#" class="btn btn-secondary">View Details</a>
                    </div>
                </div>
            </div>

            <!-- Package 3 -->
            <div class="col-md-4">
                <div class="card shadow h-100">
                    <img src="images/package3.jpg" class="card-img-top" alt="Leh-Ladakh">
                    <div class="card-body">
                        <h5 class="card-title">Leh-Ladakh Experience</h5>
                        <p class="card-text">Discover the rugged beauty of Ladakh with this adventurous 7-day package.</p>
                        <ul>
                            <li>Duration: 7 Days</li>
                            <li>Starting from: ₹35,000</li>
                        </ul>
                        <a href="#" class="btn btn-secondary">View Details</a>
                    </div>
                </div>
            </div>

            <!-- Package 4 -->
            <div class="col-md-4">
                <div class="card shadow h-100">
                    <img src="images/package4.jpg" class="card-img-top" alt="Rajasthan Tour">
                    <div class="card-body">
                        <h5 class="card-title">Rajasthan Heritage Tour</h5>
                        <p class="card-text">Immerse yourself in the royal culture of Rajasthan with this 8-day tour.</p>
                        <ul>
                            <li>Duration: 8 Days</li>
                            <li>Starting from: ₹30,000</li>
                        </ul>
                        <a href="#" class="btn btn-secondary">View Details</a>
                    </div>
                </div>
            </div>

            <!-- Package 5 -->
            <div class="col-md-4">
                <div class="card shadow h-100">
                    <img src="images/package5.jpg" class="card-img-top" alt="Kerala Backwaters">
                    <div class="card-body">
                        <h5 class="card-title">Kerala Backwaters</h5>
                        <p class="card-text">Relax and rejuvenate in the serene backwaters of Kerala with this luxurious package.</p>
                        <ul>
                            <li>Duration: 5 Days</li>
                            <li>Starting from: ₹20,000</li>
                        </ul>
                        <a href="#" class="btn btn-secondary">View Details</a>
                    </div>
                </div>
            </div>

            <!-- Package 6 -->
            <div class="col-md-4">
                <div class="card shadow h-100">
                    <img src="images/package6.jpg" class="card-img-top" alt="Goa Beach">
                    <div class="card-body">
                        <h5 class="card-title">Goa Beach Getaway</h5>
                        <p class="card-text">Enjoy the sun, sand, and sea with this exciting 4-day beach getaway in Goa.</p>
                        <ul>
                            <li>Duration: 4 Days</li>
                            <li>Starting from: ₹18,000</li>
                        </ul>
                        <a href="#" class="btn btn-secondary">View Details</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- customised package-->
    <!-- Customised Package Section -->
    <div class="container my-5 py-5 bg-gradient bg-light shadow rounded">
        <h2 class="text-center mb-4 fw-bold h-font">Create Your Customised Package</h2>
        <p class="text-center text-secondary mb-5">Your dream trip, your way! Choose your preferences, set your budget, and let us craft the perfect travel experience for you.</p>

        <div class="row g-4">
            <!-- Left Image Section -->
            <div class="col-lg-6 d-flex align-items-center">
                <div class="text-center">
                    <img src="images/customised-package.jpg" class="img-fluid rounded shadow-lg border border-3 border-warning" alt="Customised Package">
                    <p class="mt-4 text-dark">Discover exclusive destinations and enjoy a journey tailored just for you.</p>
                </div>
            </div>

            <!-- Right Form Section -->
            <div class="col-lg-6">
                <form action="submit_custom_package.php" method="POST" class="p-4 rounded shadow-lg bg-white border border-warning" style="background:aquamarine;">
                    <h4 class="fw-bold text-center text-primary mb-4">Design Your Dream Trip</h4>

                    <!-- State Dropdown -->
                    <div class="mb-3">
                        <label for="state" class="form-label text-secondary fw-semibold">Select Your Destination State</label>
                        <select id="state" name="state" class="form-select border-warning">
                            <option value="" selected disabled>Select your state</option>
                            <option value="Himachal Pradesh">Himachal Pradesh</option>
                            <option value="Rajasthan">Rajasthan</option>
                            <option value="Kerala">Kerala</option>
                            <option value="Goa">Goa</option>
                            <option value="Leh-Ladakh">Leh-Ladakh</option>
                            <option value="Uttarakhand">Uttarakhand</option>
                        </select>
                    </div>

                    <!-- Budget Range -->
                    <div class="mb-3">
                        <label for="budget" class="form-label text-secondary fw-semibold">Select Your Budget (₹)</label>
                        <input type="range" id="budget" name="budget" class="form-range" min="1000" max="25000" step="1000"
                            oninput="document.getElementById('budgetValue').innerText = this.value;">
                        <p class="text-secondary fw-semibold">Selected Budget: <span id="budgetValue" class="fw-bold text-primary">5000</span> ₹</p>
                    </div>

                    <!-- Travel Preferences -->
                    <div class="mb-3">
                        <label for="preferences" class="form-label text-secondary fw-semibold">Choose Your Travel Preferences</label>
                        <div class="d-flex flex-wrap">
                            <div class="form-check me-3 mb-2">
                                <input class="form-check-input border-warning" type="checkbox" id="adventure" name="preferences[]" value="Adventure">
                                <label class="form-check-label text-dark fw-semibold" for="adventure">Adventure</label>
                            </div>
                            <div class="form-check me-3 mb-2">
                                <input class="form-check-input border-warning" type="checkbox" id="luxury" name="preferences[]" value="Luxury">
                                <label class="form-check-label text-dark fw-semibold" for="luxury">Luxury</label>
                            </div>
                            <div class="form-check me-3 mb-2">
                                <input class="form-check-input border-warning" type="checkbox" id="culture" name="preferences[]" value="Culture">
                                <label class="form-check-label text-dark fw-semibold" for="culture">Culture</label>
                            </div>
                            <div class="form-check me-3 mb-2">
                                <input class="form-check-input border-warning" type="checkbox" id="nature" name="preferences[]" value="Nature">
                                <label class="form-check-label text-dark fw-semibold" for="nature">Nature</label>
                            </div>
                            <div class="form-check me-3 mb-2">
                                <input class="form-check-input border-warning" type="checkbox" id="beach" name="preferences[]" value="Beach">
                                <label class="form-check-label text-dark fw-semibold" for="beach">Beach</label>
                            </div>
                        </div>
                    </div>

                    <!-- Travel Dates -->
                    <div class="mb-3">
                        <label for="travelDates" class="form-label text-secondary fw-semibold">Select Your Travel Dates</label>
                        <input type="date" id="travelDates" name="travelDates" class="form-control border-warning">
                    </div>

                    <!-- Submit Button -->
                    <div class="text-center">
                        <button type="submit" class="btn btn-secondary">Submit Your Request</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <!-- Footer Section -->
    <?php require('inc/footer.php'); ?>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>