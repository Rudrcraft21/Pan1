<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Hotel Booking</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <?php require('inc/link.php'); ?>
    <?php require('inc/header.php'); ?>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 30px;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .card img {
            height: 250px;
            object-fit: cover;
        }

        .card-body {
            padding: 20px;
        }

        .card-title {
            font-size: 1.5rem;
            color: #333;
            margin-bottom: 15px;
        }

        .card-text {
            color: #555;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }

        .search-form {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .search-form .form-control {
            border-radius: 10px;
        }

        .filter-btn {
            background-color: #28a745;
            border-color: #28a745;
        }

        .filter-btn:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }

        .hotel-card-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }

        .hotel-card-container .col-md-4 {
            margin-bottom: 30px;
        }

        .footer {
            background-color: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
        }

        .footer .fa {
            margin-right: 10px;
        }

        .hotel-amenities,
        .customer-reviews,
        .special-offers {
            background-color: #ffffff;
            padding: 40px 0;
            margin-bottom: 40px;
        }

        .hotel-amenities ul,
        .customer-reviews ul {
            list-style-type: none;
            padding: 0;
        }

        .hotel-amenities li,
        .customer-reviews li {
            font-size: 1.1rem;
            color: #555;
            margin-bottom: 10px;
        }

        .special-offers {
            background-color: #f9f9f9;
        }

        .special-offers .offer {
            background-color: #007bff;
            color: white;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }

        .special-offers .offer h4 {
            margin-bottom: 10px;
        }

        #map {
            height: 400px;
            width: 100%;
        }

        .related-destinations {
            background-color: #f8f9fa;
            padding: 40px 0;
        }

        .related-destinations h2 {
            margin-bottom: 20px;
        }

        .related-destinations .card {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <!-- Booking Search Form -->
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="search-form">
                    <h3 class="text-center mb-4">Search for Hotels</h3>
                    <form action="#" method="POST">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="location" class="form-label">Location</label>
                                <input type="text" class="form-control" id="location" placeholder="City or Hotel Name">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="checkin" class="form-label">Check-in Date</label>
                                <input type="date" class="form-control" id="checkin">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="checkout" class="form-label">Check-out Date</label>
                                <input type="date" class="form-control" id="checkout">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="guests" class="form-label">Guests</label>
                                <input type="number" class="form-control" id="guests" min="1" value="1">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="rooms" class="form-label">Rooms</label>
                                <input type="number" class="form-control" id="rooms" min="1" value="1">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Search Hotels</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Hotel Listings Section -->
    <div class="container hotel-card-container">
        <h2 class="section-title text-center">Featured Hotels</h2>
        <div class="row">
            <!-- Hotel 1 -->
            <div class="col-md-4">
                <div class="card">
                    <img src="hotel1.jpg" class="card-img-top" alt="Hotel 1">
                    <div class="card-body">
                        <h5 class="card-title">Hotel Sunset</h5>
                        <p class="card-text">Experience luxury in the heart of the city with scenic views and world-class amenities.</p>
                        <p class="font-weight-bold">$250 / Night</p>
                        <a href="#" class="btn btn-primary">Book Now</a>
                    </div>
                </div>
            </div>
            <!-- Hotel 2 -->
            <div class="col-md-4">
                <div class="card">
                    <img src="hotel2.jpg" class="card-img-top" alt="Hotel 2">
                    <div class="card-body">
                        <h5 class="card-title">Hotel Oceanview</h5>
                        <p class="card-text">Enjoy breathtaking ocean views, perfect for a relaxing getaway.</p>
                        <p class="font-weight-bold">$200 / Night</p>
                        <a href="#" class="btn btn-primary">Book Now</a>
                    </div>
                </div>
            </div>
            <!-- Hotel 3 -->
            <div class="col-md-4">
                <div class="card">
                    <img src="hotel3.jpg" class="card-img-top" alt="Hotel 3">
                    <div class="card-body">
                        <h5 class="card-title">Hotel Paradise</h5>
                        <p class="card-text">A serene retreat with private villas, perfect for a quiet vacation.</p>
                        <p class="font-weight-bold">$300 / Night</p>
                        <a href="#" class="btn btn-primary">Book Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Hotel Amenities Section -->
    <div class="container hotel-amenities">
        <h2 class="section-title text-center">Hotel Amenities</h2>
        <div class="row">
            <div class="col-md-4">
                <ul>
                    <li><i class="fas fa-wifi"></i> Free Wi-Fi</li>
                    <li><i class="fas fa-swimming-pool"></i> Outdoor Pool</li>
                    <li><i class="fas fa-gym"></i> Fitness Center</li>
                </ul>
            </div>
            <div class="col-md-4">
                <ul>
                    <li><i class="fas fa-spa"></i> Spa & Wellness</li>
                    <li><i class="fas fa-utensils"></i> Restaurant</li>
                    <li><i class="fas fa-car"></i> Car Rental</li>
                </ul>
            </div>
            <div class="col-md-4">
                <ul>
                    <li><i class="fas fa-umbrella-beach"></i> Beachfront</li>
                    <li><i class="fas fa-paw"></i> Pet Friendly</li>
                    <li><i class="fas fa-hand-holding-usd"></i> Room Service</li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Customer Reviews Section -->
    <div class="container customer-reviews">
        <h2 class="section-title text-center">Customer Reviews</h2>
        <div class="row">
            <div class="col-md-6">
                <div class="review">
                    <h5>John Doe <span class="text-muted">5 Stars</span></h5>
                    <p>"Amazing experience! The service was top-notch and the amenities were fantastic."</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="review">
                    <h5>Jane Smith <span class="text-muted">4 Stars</span></h5>
                    <p>"Had a great stay, though I would have liked more food options available late at night."</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Special Offers Section -->
    <div class="container special-offers">
        <h2 class="section-title text-center">Special Offers</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="offer">
                    <h4>20% Off for Early Bookings</h4>
                    <p>Book your stay in advance and save 20% on your total booking.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="offer">
                    <h4>Family Deal: 2 for 1</h4>
                    <p>Bring your family along and get 2 rooms for the price of 1.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="offer">
                    <h4>Free Breakfast with Your Stay</h4>
                    <p>Enjoy a complimentary breakfast for two with every booking.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Map Location Section -->
    <div class="container py-5">
        <h2 class="section-title text-center">Hotel Location</h2>
        <div id="map"></div>
    </div>

    <!-- Related Destinations Section -->
    <div class="container related-destinations">
        <h2 class="section-title text-center">Related Destinations</h2>
        <div class="row">
            <!-- Destination 1 -->
            <div class="col-md-4">
                <div class="card">
                    <img src="destination1.jpg" class="card-img-top" alt="Destination 1">
                    <div class="card-body">
                        <h5 class="card-title">Paris</h5>
                        <p class="card-text">The city of love with stunning architecture, fine dining, and romantic vibes.</p>
                    </div>
                </div>
            </div>
            <!-- Destination 2 -->
            <div class="col-md-4">
                <div class="card">
                    <img src="destination2.jpg" class="card-img-top" alt="Destination 2">
                    <div class="card-body">
                        <h5 class="card-title">Bali</h5>
                        <p class="card-text">A tropical paradise offering beautiful beaches, temples, and culture.</p>
                    </div>
                </div>
            </div>
            <!-- Destination 3 -->
            <div class="col-md-4">
                <div class="card">
                    <img src="destination3.jpg" class="card-img-top" alt="Destination 3">
                    <div class="card-body">
                        <h5 class="card-title">Tokyo</h5>
                        <p class="card-text">A vibrant city blending modern tech with traditional Japanese culture.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php require('inc/footer.php'); ?>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
    <!-- Optional: Google Maps API -->
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap" async defer></script>
    <script>
        function initMap() {
            const location = { lat: -34.397, lng: 150.644 };
            const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 8,
                center: location,
            });
            new google.maps.Marker({
                position: location,
                map: map,
            });
        }
    </script>
</body>

</html>
