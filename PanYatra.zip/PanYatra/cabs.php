<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PANYATRA - Cab Booking</title>
    <?php require('inc/link.php'); ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places"></script>
    <style>
        .cab-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 10px;
        }

        .cab-card {
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .cab-card:hover {
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.2);
            transform: scale(1.03);
        }

        .booking-btn {
            background-color: #0d6efd;
            color: #fff;
            border: none;
        }

        .booking-btn:hover {
            background-color: #0056b3;
        }

        #map {
            height: 300px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .rating {
            color: #FFD700;
        }

        @media (max-width: 768px) {
            .cab-card img {
                height: 150px;
            }
        }
    </style>
</head>

<body class="bg-light">

    <!-- Header Section -->
    <?php require('inc/header.php'); ?>

    <!-- Cab Booking Banner -->
    <div class="my-5 px-4 text-center">
        <h2 class="fw-bold h-font">Book Your Cab</h2>
        <p>Reliable, affordable, and comfortable cab services at your fingertips.</p>
        <div class="h-line bg-dark mx-auto"></div>
    </div>

    <!-- Cab Options Section -->
    <div class="container">
        <div class="row">
            <!-- Cab 1 - Sedan -->
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="cab-card p-3">
                    <img src="images/sedan.jpg" alt="Sedan">
                    <h5 class="mt-3">Sedan</h5>
                    <p>Comfortable sedans perfect for small families or business trips. <br><strong>Starting at ₹10/km</strong></p>
                    <p class="rating">⭐⭐⭐⭐⭐ (120 Reviews)</p>
                    <button class="btn booking-btn w-100" data-bs-toggle="modal" data-bs-target="#bookingModal" onclick="updateBookingDetails('Sedan', '₹10/km')">Book Now</button>
                </div>
            </div>
            <!-- Cab 2 - SUV -->
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="cab-card p-3">
                    <img src="images/suv.jpg" alt="SUV">
                    <h5 class="mt-3">SUV</h5>
                    <p>Spacious SUVs for a comfortable ride with extra luggage. <br><strong>Starting at ₹15/km</strong></p>
                    <p class="rating">⭐⭐⭐⭐ (95 Reviews)</p>
                    <button class="btn booking-btn w-100" data-bs-toggle="modal" data-bs-target="#bookingModal" onclick="updateBookingDetails('SUV', '₹15/km')">Book Now</button>
                </div>
            </div>
            <!-- Cab 3 - Luxury -->
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="cab-card p-3">
                    <img src="images/luxury.jpg" alt="Luxury">
                    <h5 class="mt-3">Luxury</h5>
                    <p>Premium luxury cars for a high-class experience. <br><strong>Starting at ₹25/km</strong></p>
                    <p class="rating">⭐⭐⭐⭐⭐ (150 Reviews)</p>
                    <button class="btn booking-btn w-100" data-bs-toggle="modal" data-bs-target="#bookingModal" onclick="updateBookingDetails('Luxury', '₹25/km')">Book Now</button>
                </div>
            </div>
        </div>

        <!-- Additional Options: Other Cab Companies -->
        <div class="row mt-5">
            <div class="col-12">
                <h4 class="fw-bold">Other Cab Companies</h4>
                <div class="row">
                    <!-- Normal Cab 1 -->
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="cab-card p-3">
                            <img src="images/normal-cab.jpg" alt="Normal Cab">
                            <h5 class="mt-3">Normal Cab</h5>
                            <p>Affordable rides for everyday needs. <br><strong>Starting at ₹8/km</strong></p>
                            <p class="rating">⭐⭐⭐⭐ (80 Reviews)</p>
                            <button class="btn booking-btn w-100" data-bs-toggle="modal" data-bs-target="#bookingModal" onclick="updateBookingDetails('Normal Cab', '₹8/km')">Book Now</button>
                        </div>
                    </div>
                    <!-- Normal Cab 2 -->
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="cab-card p-3">
                            <img src="images/normal-cab2.jpg" alt="Normal Cab 2">
                            <h5 class="mt-3">City Cab</h5>
                            <p>Convenient and affordable for city travel. <br><strong>Starting at ₹7/km</strong></p>
                            <p class="rating">⭐⭐⭐⭐ (60 Reviews)</p>
                            <button class="btn booking-btn w-100" data-bs-toggle="modal" data-bs-target="#bookingModal" onclick="updateBookingDetails('City Cab', '₹7/km')">Book Now</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Booking Modal -->
    <!-- Booking Modal -->
    <div class="modal fade" id="bookingModal" tabindex="-1" aria-labelledby="bookingModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Book Your Cab - <span id="selectedCabModal"></span> (Cost: <span id="cabCost"></span>)</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Google Maps Integration -->
                        <div id="map"></div>

                        <!-- Car Type Dropdown -->
                        <div class="mb-3">
                            <label for="carSelect" class="form-label">Select Car Type</label>
                            <select class="form-control" id="carSelect" name="carSelect" required>
                                <!-- Dynamically filled options -->
                            </select>
                        </div>

                        <!-- Pickup Location -->
                        <div class="mb-3">
                            <label for="pickupLocation" class="form-label">Pickup Location</label>
                            <input type="text" class="form-control" id="pickupLocation" name="pickupLocation" placeholder="Enter Pickup Location" required>
                        </div>

                        <!-- Drop Location -->
                        <div class="mb-3">
                            <label for="dropLocation" class="form-label">Drop Location</label>
                            <input type="text" class="form-control" id="dropLocation" name="dropLocation" placeholder="Enter Drop Location" required>
                        </div>

                        <!-- Pickup Date -->
                        <div class="mb-3">
                            <label for="pickupDate" class="form-label">Pickup Date</label>
                            <input type="date" class="form-control" id="pickupDate" name="pickupDate" required>
                        </div>

                        <!-- Pickup Time -->
                        <div class="mb-3">
                            <label for="pickupTime" class="form-label">Pickup Time</label>
                            <input type="time" class="form-control" id="pickupTime" name="pickupTime" required>
                        </div>

                        <!-- Full Name -->
                        <div class="mb-3">
                            <label for="fullname" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="fullname" name="fullname" placeholder="Enter Your Full Name" required>
                        </div>

                        <!-- Email -->
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Enter Your Email Address" required>
                        </div>

                        <!-- Phone Number -->
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" id="phone" name="phone" placeholder="Enter Your Phone Number" required>
                        </div>

                        <!-- Promo Code Section -->
                        <div class="mb-3">
                            <label for="promoCode" class="form-label">Promo Code (Optional)</label>
                            <input type="text" class="form-control" id="promoCode" name="promoCode" placeholder="Enter Promo Code">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="send" class="btn btn-primary">Book Cab</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php
    if (isset($_POST['send'])) {
        $frm_data = filteration($_POST);

        // Check if fullname exists
        if (!isset($frm_data['fullname']) || empty($frm_data['fullname'])) {
            die('Full name is required!');
        }

        $q = "INSERT INTO `cabs` (Car_Select ,pickup_location, drop_location, pickup_date, pickup_time, full_name, email, phone, promo_code) 
              VALUES (?,?, ?, ?, ?, ?, ?, ?, ?)";
        $value = [

            $selectedCar = $frm_data['carSelect'], // This will contain the selected car
            $frm_data['pickupLocation'],  // Corresponds to pickup_location
            $frm_data['dropLocation'],    // Corresponds to drop_location
            $frm_data['pickupDate'],      // Corresponds to pickup_date
            $frm_data['pickupTime'],      // Corresponds to pickup_time
            $frm_data['fullname'],        // Corresponds to full_name
            $frm_data['email'],           // Corresponds to email
            $frm_data['phone'],           // Corresponds to phone
            $frm_data['promoCode']        // Corresponds to promo_code
        ];

        // Call the insert function with prepared query and values
        $res = insert($q, $value, 'sssssssss'); // 'ssssssss' indicates 8 string parameters

        // Check the result and respond accordingly
        if ($res == 1) {
            alert('success', 'Booking confirmed! Thank you for choosing us.');
            echo '<script>window.location = "booking.php";</script>';
            exit();
        } else {
            alert('error', 'Server Down! Please try again later.');
        }
    }

    ?>


    <!-- Footer Section -->
    <?php require('inc/footer.php'); ?>

    <script>
        function updateBookingDetails(carName, carCost) {
            document.getElementById('selectedCabModal').innerText = carName;
            document.getElementById('cabCost').innerText = carCost;

            // Add car names to the dropdown
            let carSelect = document.getElementById('carSelect');
            carSelect.innerHTML = ''; // Clear the previous options

            // Available car options
            const cars = ['Sedan', 'SUV', 'Luxury', 'Normal Cab', 'City Cab']; // Example cars, can be dynamically generated
            cars.forEach(function(car) {
                let option = document.createElement('option');
                option.value = car;
                option.textContent = car;
                carSelect.appendChild(option);
            });
        }
    </script>
</body>

</html>