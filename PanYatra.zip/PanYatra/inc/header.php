<?php
require('admin/inc/db_config.php');
require('admin/inc/essentials.php');

$contact_q = "SELECT * FROM `contact_details` WHERE `sr_no`=?";
$values = [1];
$contact_r = mysqli_fetch_assoc(select($contact_q, $values, 'i'));
?>

<style>
  /* General Styling */
  body {
    font-family: 'Poppins', sans-serif;
  }

  /* Navbar Styling */
  #nav-bar {
    background-color: white;
    padding: 15px 20px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }

  .navbar-brand {
    font-size: 2rem;
    font-weight: bold;
    color: #000;
    transition: color 0.3s ease, transform 0.3s ease;
    position: relative; /* Position relative to place the logo */
  }

  .navbar-brand:hover {
    color: #FFD700;
    transform: scale(1.1);
  }

  .navbar-subtitle {
    font-size: 0.9rem;
    color: #FFD700;
    font-style: italic;
  }

  .nav-link {
    color: #333;
    font-weight: 500;
    margin-right: 15px;
    position: relative;
    transition: color 0.3s ease;
  }

  .nav-link:hover {
    color: #007BFF;
  }

  .nav-link::after {
    content: '';
    display: block;
    width: 0;
    height: 2px;
    background: #FFD700;
    transition: width 0.3s;
  }

  .nav-link:hover::after {
    width: 100%;
  }

  .navbar-toggler {
    border: none;
  }

  .navbar-toggler-icon {
    color: #000;
  }

  /* Logo Style */
  .navbar-brand img {
    position: absolute;
    top: 10px;
    right: -10px;
    width: 60px;
    height: 60px;
    mix-blend-mode: multiply; /* Apply blend mode effect */
  }

  /* Buttons */
  .btn-outline-dark {
    border: 2px solid #FFD700;
    color: #FFD700;
    border-radius: 25px;
    transition: background-color 0.3s ease, color 0.3s ease;
  }

  .btn-outline-dark:hover {
    background-color: #FFD700;
    color: #000;
  }

  /* Modal and Form Styling */
  .modal-content {
    border-radius: 15px;
    overflow: hidden;
    animation: modal-fade-in 0.5s ease-in-out;
  }

  .modal-header {
    background-color: #0dcaf0;
    color: white;
    border-bottom: 0;
  }

  .modal-header h5 {
    font-size: 1.5rem;
    font-weight: bold;
  }

  .btn-close {
    background-color: transparent;
  }

  .modal-body {
    background-color: #f9f9f9;
  }

  .form-label {
    font-weight: 600;
  }

  .form-control {
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    border: 1px solid #ddd;
    padding: 10px;
    transition: box-shadow 0.3s ease, transform 0.3s ease;
  }

  .form-control:focus {
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    transform: scale(1.02);
    border-color: #0dcaf0;
  }

  .btn-primary {
    background-color: #0dcaf0;
    border-color: #0dcaf0;
    padding: 10px 15px;
    font-weight: bold;
    border-radius: 30px;
    transition: transform 0.3s ease, background-color 0.3s ease;
  }

  .btn-primary:hover {
    background-color: #0bb4d4;
    transform: scale(1.05);
  }

  /* Animations */
  @keyframes modal-fade-in {
    from {
      opacity: 0;
      transform: translateY(-30px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .modal-content {
    animation: slide-in 0.5s ease;
  }

  @keyframes slide-in {
    from {
      transform: scale(0.8);
      opacity: 0;
    }

    to {
      transform: scale(1);
      opacity: 1;
    }
  }

  /* Responsive Design */
  @media (max-width: 768px) {
    .modal-content {
      border-radius: 10px;
    }

    .modal-header h5 {
      font-size: 1.2rem;
    }

    .btn-primary {
      font-size: 0.9rem;
    }

    .navbar-brand img {
      width: 50px;
      height: 50px;
      top: 8px;
      right: -8px;
    }
  }
</style>

<nav id="nav-bar" class="navbar navbar-expand-lg navbar-light sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand h-font me-5" href="index.php">PANYATRA
      <div class="navbar-subtitle h-font">Your Journey, Our Priority</div>
      <!-- <img src="image/icon/main_logo.jpg" alt="Logo" class="hide-bg"> -->
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"><i class="bi bi-list"></i></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="bi bi-house-door-fill"></i> Home</a></li>
        <li class="nav-item"><a class="nav-link" href="packages.php"> <i class="bi bi-box-seam"></i> Packages</a></li>
        <li class="nav-item"><a class="nav-link" href="cabs.php"><i class="bi bi-car-front-fill"></i> Cabs</a></li>
        <li class="nav-item"><a class="nav-link" href="hotel.php"><i class="bi bi-house-check"></i> Hotels</a></li>
        <li class="nav-item"><a class="nav-link" href="booking.php"><i class="bi bi-calendar-check"></i> Booking</a></li>
        <li class="nav-item"><a class="nav-link" href="contact.php"><i class="bi bi-telephone-fill"></i> Contact Us</a></li>
        <li class="nav-item"><a class="nav-link" href="blog.php"><i class="bi bi-chat-left-text"></i> Blog</a></li>
        <li class="nav-item"><a class="nav-link" href="about.php"><i class="bi bi-info-circle-fill"></i> About</a></li>
      </ul>
      <div class="d-flex">
        <button class="btn btn-outline-dark me-2" data-bs-toggle="modal" data-bs-target="#loginModal"><i class="bi bi-box-arrow-in-right"></i> Login</button>
        <button class="btn btn-outline-dark" data-bs-toggle="modal" data-bs-target="#registerModal"><i class="bi bi-person-plus"></i> Register</button>
      </div>
    </div>
  </div>
</nav>

<!-- Login Modal -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form>
        <div class="modal-header">
          <h5 class="modal-title"><i class="fas fa-sign-in-alt"></i> Login</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" placeholder="you@example.com" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" class="form-control" placeholder="********" required>
          </div>
          <button type="submit" class="btn btn-primary w-100">Login</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Register Modal -->
<div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="registerModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form>
        <div class="modal-header">
          <h5 class="modal-title"><i class="fas fa-user-plus"></i> Register</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" class="form-control" placeholder="Your Name" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" placeholder="you@example.com" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" class="form-control" placeholder="********" required>
          </div>
          <button type="submit" class="btn btn-primary w-100">Register</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function(el) {
    new bootstrap.Tooltip(el);
  });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>