<div class="footer bg-dark text-white py-5 position-relative">
    <div class="container">
        <div class="row text-center text-md-start">
            <!-- About Section -->
            <div class="col-lg-4 p-4">
                <h4 class="footer-title text-info fw-bold mb-3 animate__animated animate__fadeInLeft h-font">PANYATRA</h4>
                <p class="footer-about mt-3">
                    Explore the world with us! At Panyatra, we bring the joy of travel to you, handling everything from
                    logistics to luxurious experiences. Discover new places, adventures, and memories waiting to be made.
                </p>
            </div>
            <!-- Quick Links Section -->
            <div class="col-lg-2 p-4">
                <h4 class="footer-title text-info mb-3 animate__animated animate__fadeInRight h-font">Quick Links</h4>
                <ul class="footer-links list-unstyled">
                    <li><a href="index.php" class="text-white text-decoration-none">Home</a></li>
                    <li><a href="facilities.php" class="text-white text-decoration-none">Facilities</a></li>
                    <li><a href="career.php" class="text-white text-decoration-none">Career</a></li>
                    <li><a href="contact.php" class="text-white text-decoration-none">Contact Us</a></li>
                    <li><a href="contact.php" class="text-white text-decoration-none">FAQ</a></li>
                    <li><a href="contact.php" class="text-white text-decoration-none">Blog</a></li>
                </ul>
            </div>
            <!-- Services Section -->
            <div class="col-lg-2 p-4">
                <h4 class="footer-title text-info mb-3 animate__animated animate__fadeInRight h-font">Our Services</h4>
                <ul class="footer-links list-unstyled">
                    <li><a href="#services" class="text-white text-decoration-none">Guided Tours</a></li>
                    <li><a href="#services" class="text-white text-decoration-none">Hotel Bookings</a></li>
                    <li><a href="#services" class="text-white text-decoration-none">Flight Reservations</a></li>
                    <li><a href="#services" class="text-white text-decoration-none">Customized Packages</a></li>
                    <li><a href="#services" class="text-white text-decoration-none">Transportation Services</a></li>
                </ul>
            </div>
            <!-- Newsletter and Socials Section -->
            <div class="col-lg-4 p-4 text-center text-md-start">
                <h4 class="footer-title text-info mb-3 animate__animated animate__fadeInUp h-font">Stay Connected</h4>
                <p class="footer-newsletter-text">
                    Subscribe to our newsletter for the latest updates and insights in the logistics industry.
                </p>
                <form class="d-flex">
                    <input type="email" placeholder="Your email" class="form-control me-2">
                    <button type="submit" class="btn btn-info">Subscribe</button>
                </form>
                <div class="social-icons mt-3">
                    <a href="#" class="text-white me-3"><i class="bi bi-twitter"></i></a>
                    <a href="#" class="text-white me-3"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="text-white me-3"><i class="bi bi-facebook"></i></a>
                </div>
            </div>
        </div>
        <!-- Footer Bottom Text -->
        <div class="text-center mt-4 pt-2 border-top border-secondary">
            <p class="small text-muted mb-0">Designed and Developed by RudraCraft Infotech ©2024 Panyatra. All rights reserved.</p>
        </div>
    </div>
</div>

<!-- Footer CSS -->
<style>
    .footer {
        background: black;
        color: #f1f1f1;
    }

    .footer-title {
        font-size: 1.5rem;
    }

    .footer-about,
    .footer-links li,
    .footer-newsletter-text {
        animation: fadeIn 1.2s ease-in-out;
    }

    .footer-links li {
        list-style: none;
        margin-bottom: 10px;
    }

    .footer-links li a:hover {
        color: #17a2b8;
        transition: color 0.3s ease;
    }

    .social-icons a:hover {
        color: #17a2b8;
        transform: scale(1.2);
        transition: transform 0.3s ease;
    }

    @keyframes fadeIn {
        0% {
            opacity: 0;
            transform: translateY(20px);
        }

        100% {
            opacity: 1;
            transform: translateY(0);
        }
    }
</style>

<!-- Animation Library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />