<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PANYATRA - About</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <?php require('inc/link.php'); ?>

    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f1f3f6;
            color: #333;
        }

        .h-font {
            font-family: 'Lora', serif;
        }

        .section-heading {
            font-size: 2.5rem;
            font-weight: bold;
            color: #1e3a8a;
            text-align: center;
            margin-bottom: 30px;
        }

        .section-subheading {
            color: #555;
            font-size: 1.15rem;
            text-align: center;
            margin-bottom: 50px;
        }

        .img {
            width: 100%;
            max-width: 350px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease;
            cursor: pointer;
            margin-top: 30px;
        }

        .img:hover {
            transform: scale(1.1);
        }

        .feature-box {
            background-color: #fff;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            text-align: center;
        }

        .feature-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
        }

        .feature-img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            margin-bottom: 20px;
        }

        .feature-title {
            font-size: 1.2rem;
            color: #1e3a8a;
            font-weight: 600;
        }

        .team-member {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        .team-member img {
            width: 100%;
            border-bottom: 4px solid #f4f6f9;
        }

        .team-member h5 {
            margin-top: 20px;
            font-size: 1.2rem;
            font-weight: 700;
            color: #333;
        }

        .team-member p {
            font-size: 1rem;
            color: #777;
        }

        .btn-custom {
            background-color: #1e3a8a;
            color: #fff;
            padding: 12px 30px;
            font-size: 1.1rem;
            border-radius: 30px;
            transition: background-color 0.3s ease;
            text-decoration: none;
        }

        .btn-custom:hover {
            background-color: #375e8b;
        }

        .section {
            padding: 50px 0;
        }

        .swiper-container {
            margin-top: 50px;
        }
    </style>
</head>

<body>

    <?php require('inc/header.php'); ?>

    <!-- About Us Section -->
    <div class="container section">
        <h2 class="section-heading h-font">About Us</h2>
        <p class="section-subheading">
            We are a leading provider of innovative logistics solutions, facilitating trade across Bihar.<br>
            Our approach is rooted in sustainability, responsibility, and making a meaningful impact in every community we serve.
        </p>
    </div>

    <!-- Message from Founder -->
    <div class="container section">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h3 class="h-font mb-3 text-center">Message from the Founder</h3>
                <p class="text-center">
                    At FRIENDS LOGISTICS, we strive to redefine industry standards in logistics and supply chain management. With innovation and efficiency at our core, we aim to provide solutions that make a tangible impact.
                </p>
                <p class="text-center">
                    Our team is passionate about delivering excellent service, leveraging the latest technologies to stay ahead in the market. Join us as we continue to evolve and build sustainable solutions.
                </p>
                <p class="text-center">
                    Thank you for being a part of our journey. We look forward to a successful and collaborative future ahead.
                </p>
                <p class="text-center fw-bold mb-0">Sincerely,</p>
                <p class="text-info fw-bold text-center">Lilit Gill <br> Vinit Verma <br> Rishul Verma <br> Siddhant Bharti </p>
            </div>
            <div class="col-lg-6 text-center">
                <img src="image/about/prj6.jpg" alt="Founder Image" class="img">
            </div>
        </div>
    </div>

    <!-- Core Features Section -->
    <div class="container section">
        <h3 class="section-heading h-font text-center">Core Features</h3>
        <div class="row">
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="feature-box">
                    <img src="image/Fast.png" alt="Fast" class="feature-img">
                    <h4 class="feature-title">Speed</h4>
                    <p>We ensure rapid delivery, reducing the time it takes to move goods from one point to another.</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="feature-box">
                    <img src="image/secure.jpg" alt="Secure" class="feature-img">
                    <h4 class="feature-title">Security</h4>
                    <p>Your goods are always safe with us, with state-of-the-art security measures in place.</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="feature-box">
                    <img src="image/track.png" alt="Track" class="feature-img">
                    <h4 class="feature-title">Track Your Parcel</h4>
                    <p>Our tracking system allows you to stay updated with real-time information on your shipments.</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="feature-box">
                    <img src="image/cost.png" alt="Cost Effective" class="feature-img">
                    <h4 class="feature-title">Affordable</h4>
                    <p>We offer competitive pricing without compromising on quality or efficiency.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Management Team Section -->
    <h3 class="section-heading h-font text-center">Our Management Team</h3>
    <div class="container section">
        <div class="swiper mySwiper">
            <div class="swiper-wrapper">
                <?php
                    $about_r = selectAll('team_details');
                    $path = ABOUT_IMG_PATH;
                    while ($row = mysqli_fetch_assoc($about_r)) {
                        echo <<<data
                        <div class="swiper-slide">
                            <div class="team-member">
                                <img src="$path$row[picture]" alt="$row[name]">
                                <h5>$row[name]</h5>
                            </div>
                        </div>
                        data;
                    }
                ?>
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </div>

    <?php require('inc/footer.php'); ?>

    <!-- JavaScript and Swiper Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script>
        var swiper = new Swiper(".mySwiper", {
            spaceBetween: 30,
            pagination: {
                el: ".swiper-pagination",
                dynamicBullets: true,
            },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                },
                768: {
                    slidesPerView: 2,
                },
                1024: {
                    slidesPerView: 3,
                },
            }
        });
    </script>

</body>

</html>
