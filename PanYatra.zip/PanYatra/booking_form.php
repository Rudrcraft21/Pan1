<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PANYATRA - Book Your Tour</title>
    <?php require('inc/link.php') ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f3f4f6, #e9ecef);
            animation: fadeIn 1s ease-in-out;
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
                transform: translateY(-20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-top: 40px;
            gap: 20px;
        }

        /* Left Side: Animated Travel Cards */
        .travel-cards {
            flex: 1;
        }

        .travel-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .travel-card img {
            max-width: 100%;
            border-radius: 10px;
            margin-bottom: 15px;
        }

        .travel-card h5 {
            font-size: 1.2rem;
            color: #ffaa16;
        }

        .travel-card:hover {
            transform: scale(1.05);
            box-shadow: 0px 15px 30px rgba(0, 0, 0, 0.2);
        }

        /* Right Side: Booking Form */
        .custom-container {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0px 10px 25px rgba(0, 0, 0, 0.1);
            width: 40%;
            animation: slideIn 0.8s ease-in-out;
        }

        @keyframes slideIn {
            0% {
                transform: translateY(50px);
                opacity: 0;
            }
            100% {
                transform: translateY(0);
                opacity: 1;
            }
        }

        input,
        select,
        textarea {
            border: 2px solid #ffaa16;
            border-radius: 5px;
            transition: all 0.3s;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: #d48811;
            box-shadow: 0px 0px 10px rgba(255, 170, 22, 0.5);
            transform: scale(1.02);
        }

        .btn-custom {
            background-color: #ffaa16;
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease-in-out;
        }

        .btn-custom:hover {
            background-color: #d48811;
            transform: scale(1.05);
        }
    </style>
</head>
<?php require('inc/header.php') ?>

<body>

    <div class="container">

        <!-- Left Side: Travel Cards -->
        <div class="travel-cards">
            <div class="travel-card">
                <img src="path-to-image-1.jpg" alt="Manali Trip">
                <h5>Manali-Kullu-Shimla</h5>
                <p>5 Nights/6 Days</p>
            </div>
            <div class="travel-card">
                <img src="path-to-image-2.jpg" alt="Shimla Weekend">
                <h5>Shimla Weekend</h5>
                <p>3 Nights/4 Days</p>
            </div>
            <div class="travel-card">
                <img src="path-to-image-3.jpg" alt="Adventure Package">
                <h5>Kullu-Manali Adventure</h5>
                <p>4 Nights/5 Days</p>
            </div>
        </div>

        <!-- Right Side: Booking Form -->
        <div class="custom-container">
            <h3 class="text-center h-font text-uppercase mb-4">Book Your Dream Tour</h3>
            <form method="POST">
                <!-- Personal Details -->
                <div class="mb-3">
                    <label for="name" class="form-label">Your Name</label>
                    <input type="text" id="name" name="name" required class="form-control shadow-none">
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email Address</label>
                    <input type="email" id="email" name="email" required class="form-control shadow-none">
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label">Phone Number</label>
                    <input type="tel" id="phone" name="phone" required class="form-control shadow-none">
                </div>
                <div class="mb-3">
                    <label for="date" class="form-label">Preferred Travel Date</label>
                    <input type="date" id="date" name="date" required class="form-control shadow-none">
                </div>

                <!-- Package Details -->
                <div class="mb-3">
                    <label for="package" class="form-label">Choose a Package</label>
                    <select id="package" name="package" class="form-select shadow-none" required>
                        <option value="">Choose a Package</option>
                        <option value="Manali-Kullu-Shimla 5N/6D">Manali-Kullu-Shimla (5 Nights/6 Days)</option>
                        <option value="Shimla Weekend 3N/4D">Shimla Weekend (3 Nights/4 Days)</option>
                        <option value="Kullu-Manali Adventure 4N/5D">Kullu-Manali Adventure (4 Nights/5 Days)</option>
                    </select>
                </div>

                <!-- Preferences -->
                <div class="mb-3">
                    <label for="message" class="form-label">Any Specific Requirements</label>
                    <textarea id="message" name="message" class="form-control shadow-none" rows="4" style="resize: none"></textarea>
                </div>

                <!-- Submit Button -->
                <div class="text-center">
                    <button type="submit" name="send" class="btn btn-custom w-100">Book Now</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Footer Section -->
    <?php require('inc/footer.php') ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>



<?php
if (isset($_POST['send'])) {
    $frm_data = filteration($_POST);

    // Prepare the SQL query for insertion
    $q = "INSERT INTO `bookings` (`name`, `email`, `phone`, `travel_date`, `package`, `message`) 
            VALUES (?, ?, ?, ?, ?, ?)";

    // Prepare values for insertion
    $value = [
        $frm_data['name'],
        $frm_data['email'],          // Corresponds to email
        $frm_data['phone'],          // Corresponds to phone
        $frm_data['date'],           // Corresponds to travel_date
        $frm_data['package'],        // Corresponds to package
        isset($frm_data['message']) ? $frm_data['message'] : '' // Corresponds to message (optional)
    ];

    // Execute the query using the insert function
    $res = insert($q, $value, 'ssssss'); // 'ssssss' indicates 6 string parameters

    // Check the result and respond accordingly
    if ($res == 1) {
        alert('success', 'Your tour booking has been submitted successfully!');
        echo '<script>window.location = "booking_form.php";</script>';
        exit();
    } else {
        alert('error', 'Server Down! Please try again later.');
    }
}
?>