<?php 
require('inc/essentials.php');
adminLogin();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel- Dashboard</title>
    <?php require('inc/link.php'); ?>
</head>
<body class="bg-light">
     
    <?php
    require('inc/header.php');
    ?>

    <div class="container-fluid" id="main-content">
        <div class="row">
            <div class="col-lg-10 ms-auto p-4 overflow-hidden">
              ntemporibus alias cupiditate. Quasi quo, repudiandae porro, quam sapiente eos consequuntur ut praesentium, illo error quod et. Ullam cumque totam quaerat fuga voluptas eligendi molestiae necessitatibus voluptate animi laboriosam odio, praesentium ut, maiores aspernatur? Quis ut aliquid doloribus adipisci placeat cumque temporibus, sapiente nesciunt facere, veniam doloremque, exercitationem ipsam deserunt. Dolor, ipsum natus molestias fugiat exercitationem eveniet voluptate magnam sequi praesentium voluptas odio suscipit nemo? Nesciunt quibusdam nobis quam asperiores voluptatum, quia ex repudiandae laboriosam qui ab minus dolores itaque explicabo ipsum nisi temporibus corrupti, officiis voluptates iure molestiae sapiente? Similique ab mollitia alias dolor soluta saepe at odio eveniet, officia molestiae corrupti excepturi rem et, placeat quidem quibusdam blanditiis nostrum quos amet earum autem. Recusandae natus neque quo magni eum tempora dolor quisquam, laboriosam consequatur quis corrupti possimus quibusdam nihil nulla error. Accusantium amet reiciendis impedit, labore asperiores odit. Optio alias labore molestias, maxime fugit similique officia quam atque, aperiam inventore, repudiandae illo voluptas placeat. Corporis exercitationem impedit neque, obcaecati omnis pariatur! Perferendis cupiditate velit iure praesentium, non provident nisi animi, recusandae cum, dolores ipsa id voluptate! Optio reiciendis debitis corporis provident doloribus unde eum similique tempora!
            </div>
        </div>
    </div>

    <!-- Other content of your page goes here -->
    <?php require('inc/script.php'); ?>

</body>
</html>
