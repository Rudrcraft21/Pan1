<?php
require('../inc/db_config.php');
require('../inc/essentials.php');
adminLogin();

if (isset($_POST['add_Hotel'])) {
    $frm_data = filteration($_POST);

    $img_r = uploadImage($_FILES['image'], HOTEL_FOLDER);

    if ($img_r == 'inv_img') {
        echo $img_r;
    } elseif ($img_r == 'inv_size') {
        echo $img_r;
    } elseif ($img_r == 'upd_failed') {
        echo $img_r;
    } else {
        $q = "INSERT INTO `Hotels`(`image`, `location`, `description`, `old_price`, `new_price`, `duration`) 
              VALUES (?, ?, ?, ?, ?, ?)";
        $values = [
            $img_r,
            $frm_data['location'],
            $frm_data['description'],
            $frm_data['old_price'] ?? null, // Handle optional old price
            $frm_data['new_price'],
            $frm_data['duration'],
        ];
        $res = insert($q, $values, 'ssssss');
        echo $res;
    }
}

if (isset($_POST['get_Hotels'])) {
    $res = selectAll('Hotels');

    if (mysqli_num_rows($res) > 0) {
        echo <<< table
            <table class="table table-striped table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Image</th>
                        <th scope="col">Location</th>
                        <th scope="col">Description</th>
                        <th scope="col">Old Price</th>
                        <th scope="col">New Price</th>
                        <th scope="col">Duration</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
        table;

        $i = 1; // Counter for the table row number
        $path = HOTEL_IMG_PATH;
        while ($row = mysqli_fetch_assoc($res)) {
            echo <<< row
                <tr>
                    <td>$i</td>
                    <td><img src="$path$row[image]" alt="Hotel Image" class="img-thumbnail" style="width: 80px; height: 80px; object-fit: cover;"></td>
                    <td>$row[location]</td>
                    <td class="text-truncate" style="max-width: 200px;">$row[description]</td>
                    <td class="text-danger text-decoration-line-through">$row[old_price]</td>
                    <td class="fw-bold text-success">$row[new_price]</td>
                    <td>$row[duration]</td>
                    <td>
                        <button type="button" onclick="remHotel($row[id])" class="btn btn-danger btn-sm shadow-none">
                            <i class="bi bi-trash"></i>
                        </button>
                        <button type="button" onclick="editHotel($row[id])" class="btn btn-primary btn-sm shadow-none">
                            <i class="bi bi-pencil-square"></i>
                        </button>
                    </td>
                </tr>
            row;
            $i++;
        }

        echo <<< endtable
                </tbody>
            </table>
        endtable;
    } else {
        echo '<p class="text-center">No Hotels found!</p>';
    }
}


if (isset($_POST['rem_Hotel'])) {
    $frm_data = filteration($_POST);
    $values = [$frm_data['rem_Hotel']];

    // Get the image name before deleting the record
    $pre_q = "SELECT image FROM `Hotels` WHERE `id` = ?";
    $res = select($pre_q, $values, 'i');

    if (mysqli_num_rows($res) == 1) {
        $img = mysqli_fetch_assoc($res);

        // Delete the image file from the server
        if (deleteImage($img['image'], HOTEL_FOLDER)) {
            $q = "DELETE FROM `Hotels` WHERE `id` = ?";
            $res = delete($q, $values, 'i');
            echo $res;
        } else {
            echo 0; // Error while deleting the image
        }
    } else {
        echo 0; // Record not found
    }
}
