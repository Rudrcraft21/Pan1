<?php
require('../inc/db_config.php');
require('../inc/essentials.php');
adminLogin();

if (isset($_POST['add_location'])) {
    $frm_data = filteration($_POST);

    // Debug inputs
    print_r($frm_data);
    print_r($_FILES);

    // Upload the image
    $img_r = uploadImage($_FILES['location_image'], LOCATION_FOLDER);

    // Debug image upload result
    echo "Upload Result: " . $img_r;

    if ($img_r == 'inv_img' || $img_r == 'inv_size' || $img_r == 'upd_failed') {
        echo $img_r; // Return the error response
    } else {
        // Prepare the insert query
        $q = "INSERT INTO `location` (`image`, `location_name`, `location_desc`) VALUES (?, ?, ?)";
        $values = [$img_r, $frm_data['location_name'], $frm_data['location_desc']];

        // Execute the query
        $res = insert($q, $values, 'sss');

        // Debug the result
        if ($res) {
            echo "Insert successful!";
        } else {
            echo "Insert failed: " . $conn->error;
        }
    }
}

if (isset($_POST['get_location'])) {
    $res = selectAll('location');

    if (mysqli_num_rows($res) > 0) {
        while ($row = mysqli_fetch_assoc($res)) {
            $path = LOCATION_IMG_PATH;
            echo <<<data
            <div class="col-md-4 mb-4" data-id="$row[id]">
                <div class="card shadow h-100">
                    <img src="$path$row[image]" class="card-img-top" alt="location Image">
                    <div class="card-body">
                        <h5 class="card-title">$row[location_name]</h5>
                        <p class="card-text text-muted">$row[location_desc]</p>
                        <div class="d-flex justify-content-between">
                            <button type="button" onclick="remlocation($row[id])" class="btn btn-danger btn-sm shadow-none">
                                <i class="bi bi-trash"></i> Delete
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        data;
        }
    } else {
        echo '<p class="text-center">No location found!</p>';
    }
}

if (isset($_POST['rem_location'])) {
    $frm_data = filteration($_POST);
    $values = [$frm_data['rem_location']];

    // Get the image name before deleting the record
    $pre_q = "SELECT image FROM `location` WHERE `id` = ?";
    $res = select($pre_q, $values, 'i');

    if (!$res) {
        echo "Error: " . mysqli_error($conn);
        exit;
    }

    if (mysqli_num_rows($res) == 1) {
        $img = mysqli_fetch_assoc($res);

        // Debug image deletion
        if (deleteImage($img['image'], LOCATION_FOLDER)) {
            $q = "DELETE FROM `location` WHERE `id` = ?";
            $res = delete($q, $values, 'i');
            echo $res ? 1 : 0; // Echo 1 for success, 0 for failure
        } else {
            echo 0; // Error while deleting the image
        }
    } else {
        echo 0; // Record not found
    }
}
?>
