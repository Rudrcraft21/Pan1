<?php
require('../inc/db_config.php');
require('../inc/essentials.php');
adminLogin();

if (isset($_POST['add_destination'])) {
    $frm_data = filteration($_POST);

    $img_r = uploadImage($_FILES['location_image'], LATEST_FOLDER);

    if ($img_r == 'inv_img') {
        echo $img_r;
    } elseif ($img_r == 'inv_size') {
        echo $img_r;
    } elseif ($img_r == 'upd_failed') {
        echo $img_r;
    } else {
        $q = "INSERT INTO `destinations`(`location_image`, `location`, `description`, `old_price`, `new_price`, `duration`) 
              VALUES (?, ?, ?, ?, ?, ?)";
        $values = [
            $img_r,
            $frm_data['location'],
            $frm_data['description'],
            $frm_data['old_price'] ?? null, // Handle optional old price
            $frm_data['new_price'],
            $frm_data['duration'],
        ];
        $res = insert($q, $values, 'ssssss');
        echo $res;
    }
}

if (isset($_POST['get_destinations'])) {
    $res = selectAll('destinations');

    if (mysqli_num_rows($res) > 0) {
        while ($row = mysqli_fetch_assoc($res)) {
            $path = LATEST_IMG_PATH;
            echo <<< data
                <div class="col-md-4 mb-4">
                    <div class="card shadow h-100">
                        <img src="$path$row[location_image]" class="card-img-top" alt="Destination Image">
                        <div class="card-body">
                            <h5 class="card-title">$row[location]</h5>
                            <p class="card-text text-muted">$row[description]</p>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="text-decoration-line-through text-danger">$row[old_price]</span>
                                <span class="fw-bold text-success">$row[new_price]</span>
                            </div>
                            <p class="mb-2"><i class="bi bi-clock"></i> Duration: $row[duration]</p>
                            <div class="d-flex justify-content-between">
                                <button type="button" onclick="remDestination($row[id])" class="btn btn-danger btn-sm shadow-none">
                                    <i class="bi bi-trash"></i> Delete
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            data;
        }
    } else {
        echo '<p class="text-center">No destinations found!</p>';
    }
}

if (isset($_POST['rem_destination'])) {
    $frm_data = filteration($_POST);
    $values = [$frm_data['rem_destination']];

    // Get the image name before deleting the record
    $pre_q = "SELECT location_image FROM `destinations` WHERE `id` = ?";
    $res = select($pre_q, $values, 'i');

    if (mysqli_num_rows($res) == 1) {
        $img = mysqli_fetch_assoc($res);

        // Delete the image file from the server
        if (deleteImage($img['location_image'], LATEST_FOLDER)) {
            $q = "DELETE FROM `destinations` WHERE `id` = ?";
            $res = delete($q, $values, 'i');
            echo $res;
        } else {
            echo 0; // Error while deleting the image
        }
    } else {
        echo 0; // Record not found
    }
}
?>
