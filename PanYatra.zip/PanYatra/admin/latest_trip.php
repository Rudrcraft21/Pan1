<?php
require('inc/essentials.php');
adminLogin();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel- Latest Trip </title>
    <?php require('inc/link.php'); ?>
</head>

<body class="bg-light">

    <?php require('inc/header.php'); ?>

    <div class="container-fluid" id="main-content">
        <div class="row">
            <div class="col-lg-10 ms-auto p-4 overflow-hidden">
                <h3 class="mb-4">LATEST TRIP</h3>

                <!-- contact details section -->
                <div class="card border-0 shadow mb-4">
                    <div class="card-body">
                        <!-- Header with Title and Button -->
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <h5 class="card-title m-0">Destination Management</h5>
                            <button type="button" class="btn btn-dark shadow-none btn-sm" data-bs-toggle="modal" data-bs-target="#destination-modal">
                                <i class="bi bi-plus-circle"></i> Add New
                            </button>
                        </div>

                        <!-- Table Section -->
                        <div class="row" id="destination-data">
                        </div>
                    </div>
                </div>


                <!-- Destination Modal -->
                <div class="modal fade" id="destination-modal" tabindex="-1" aria-labelledby="destinationModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <form id="destination_s_form">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="destinationModalLabel">Add/Edit Destination</h5>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label fw-bold">Location Image</label>
                                                <input type="file" name="location_image" id="location_image" accept=".jpg, .png, .webp, .jpeg, .avif" class="form-control shadow-none" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="destination-location" class="form-label fw-bold">Location</label>
                                                <input type="text" id="destination_location" name="location" class="form-control shadow-none" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="destination-description" class="form-label fw-bold">Description</label>
                                                <textarea id="destination_description" name="description" class="form-control shadow-none" rows="3" required></textarea>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="destination-old-price" class="form-label fw-bold">Old Price</label>
                                                <input type="text" id="destination_old_price" name="old-price" class="form-control shadow-none">
                                            </div>
                                            <div class="mb-3">
                                                <label for="destination-new-price" class="form-label fw-bold">New Price</label>
                                                <input type="text" id="destination_new_price" name="new-price" class="form-control shadow-none" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="destination-duration" class="form-label fw-bold">Duration</label>
                                                <input type="text" id="destination_duration" name="duration" class="form-control shadow-none" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary shadow-none" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-primary shadow-none">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Other content of your page goes here -->
    <?php require('inc/script.php'); ?>
    <script src="scripts/latest_trip.js"></script>

</body>

</html>