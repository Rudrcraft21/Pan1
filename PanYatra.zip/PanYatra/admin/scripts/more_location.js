// Function to add or update a location
document.addEventListener("DOMContentLoaded", function () {
    let location_s_form = document.getElementById("location_s_form");
    let location_image_inp = document.getElementById("location_image_inp");
    let location_name = document.getElementById("location_name");
    let location_desc = document.getElementById("location_desc");
  
    // Handle form submission for adding or editing locations
    location_s_form.addEventListener("submit", function (e) {
      e.preventDefault();
      add_location();
    });
  
    // Function to add or update a location
    function add_location() {
      let data = new FormData();
  
      // Append all form data
      data.append("location_image", location_image_inp.files[0]); // File input
      data.append("location_name", location_name.value); // location name
      data.append("location_desc", location_desc.value); // location description
      data.append("add_location", ""); // Key to identify backend operation
  
      // Create an AJAX request
      let xhr = new XMLHttpRequest();
      xhr.open("POST", "ajax/more_location_crud.php", true);
  
      xhr.onload = function () {
        let myModal = new bootstrap.Modal(
          document.getElementById("location-modal")
        );
        myModal.hide();
  
        if (this.responseText === "inv_img") {
          alert("error", "Only JPG and PNG images are allowed!");
        } else if (this.responseText === "inv_size") {
          alert("error", "Image should be less than 2MB!");
        } else if (this.responseText === "upd_failed") {
          alert("error", "Image upload failed. Server Down");
        } else {
          alert("success", "New location added");
  
          // Refresh locations list
          get_location();
        }
      };
  
      xhr.send(data);
    }
  });
  
  // Fetch and display locations
  function get_location() {
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "ajax/more_location_crud.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  
    xhr.onload = function () {
      document.getElementById("location-data").innerHTML = this.responseText;
    };
  
    xhr.send("get_location");
  }
  
  // Remove a location
  function remlocation(id) {
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "ajax/more_location_crud.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  
    xhr.onload = function () {
      console.log(this.responseText); // Debug response
      if (this.responseText == 1) {
        // Find and remove the corresponding card from the DOM
        let locationCard = document.querySelector(`[data-id='${id}']`);
        if (locationCard) {
          locationCard.remove();
        }
        alert("success", "Location removed successfully");
      } else {
        alert("error", "Failed to remove location. Server Down");
      }
    };
  
    xhr.send("rem_location=" + id);
  }

  function clearForm() {
    location_image_inp.value = "";
    location_name.value = "";
    location_desc.value = "";
  }
  
  // Load locations on page load
  window.onload = () => {
    get_location();
  };
  