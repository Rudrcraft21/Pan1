// Get all the necessary DOM elements
let Hotel_s_form = document.getElementById("Hotel_s_form");
let image = document.getElementById("Hotel_image"); // Corrected to match the ID in HTML
let Hotel_location = document.getElementById("Hotel_location");
let Hotel_description = document.getElementById("Hotel_description");
let Hotel_old_price = document.getElementById("Hotel_old_price");
let Hotel_new_price = document.getElementById("Hotel_new_price");
let Hotel_duration = document.getElementById("Hotel_duration");

// Handle form submission for adding or editing Hotels
hotel_s_form.addEventListener("submit", function (e) {
  e.preventDefault();
  add_Hotel();
});

// Function to add or update a Hotel
function add_Hotel() {
  let data = new FormData();

  // Append all form data
  data.append("image", image.files[0]); // File input
  data.append("location", Hotel_location.value); // Location name
  data.append("description", Hotel_description.value); // Description
  data.append("old_price", Hotel_old_price.value); // Old price
  data.append("new_price", Hotel_new_price.value); // New price
  data.append("duration", Hotel_duration.value); // Duration
  data.append("add_Hotel", ""); // Key to identify backend operation

  // Create an AJAX request
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "ajax/hotel_crud.php", true);

  xhr.onload = function () {
    console.log("Server Response: ", this.responseText);
    
    // Ensure modal is initialized correctly
    let myModalElement = document.getElementById("hotel-modal");
    
    // Check if modal element is available before trying to hide it
    if (myModalElement) {
        let myModal = new bootstrap.Modal(myModalElement);
        myModal.hide();  // Hide the modal after success
    }

    if (this.responseText === "inv_img") {
        alert("error", "Only JPG and PNG images are allowed!");
    } else if (this.responseText === "inv_size") {
        alert("error", "Image should be less than 2MB!");
    } else if (this.responseText === "upd_failed") {
        alert("error", "Image upload failed. Server Down");
    } else {
        alert("success", "New Hotel added");

        // Clear the form inputs
        clearForm();
    }
};

  xhr.send(data);
}

// Fetch and display Hotels
function get_Hotels() {
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "ajax/hotel_crud.php", true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

  xhr.onload = function () {
    console.log("Server Response: ", this.responseText);
    // Update the Hotels container with fetched data
    document.getElementById("hotel-data").innerHTML = this.responseText;
  };

  xhr.send("get_Hotels"); // Key to trigger fetching Hotels
}

// Remove a Hotel
function remHotel(id) {
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "ajax/hotel_crud.php", true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

  xhr.onload = function () {
    // Handle the response from the backend
    if (this.responseText == 1) {
      alert("success", "Hotel removed successfully");
      get_Hotels(); // Refresh the Hotels list
    } else {
      alert("error", "Failed to remove Hotel. Server Down");
    }
  };

  xhr.send("rem_Hotel=" + id); // Send the Hotel ID to delete
}

// Function to clear the form inputs
function clearForm() {
  image.value = "";
  Hotel_location.value = "";
  Hotel_description.value = "";
  Hotel_old_price.value = "";
  Hotel_new_price.value = "";
  Hotel_duration.value = "";
}

// Load Hotels on page load
window.onload = () => {
  get_Hotels();
};
