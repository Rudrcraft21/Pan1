// Get all the necessary DOM elements
let destination_s_form = document.getElementById("destination_s_form");
let location_image = document.getElementById("location_image");
let destination_location = document.getElementById("destination_location");
let destination_description = document.getElementById("destination_description");
let destination_old_price = document.getElementById("destination_old_price");
let destination_new_price = document.getElementById("destination_new_price");
let destination_duration = document.getElementById("destination_duration");

// Handle form submission for adding or editing destinations
destination_s_form.addEventListener("submit", function (e) {
  e.preventDefault();
  add_destination();
});

// Function to add or update a destination
function add_destination() {
  let data = new FormData();

  // Append all form data
  data.append("location_image", location_image.files[0]); // File input
  data.append("location", destination_location.value); // Location name
  data.append("description", destination_description.value); // Description
  data.append("old_price", destination_old_price.value); // Old price
  data.append("new_price", destination_new_price.value); // New price
  data.append("duration", destination_duration.value); // Duration
  data.append("add_destination", ""); // Key to identify backend operation

  // Create an AJAX request
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "ajax/latest_crud.php", true);

  xhr.onload = function () {
    // Handle the response from the backend
    let myModal = new bootstrap.Modal(document.getElementById("destination-modal"));
    myModal.hide();

    if (this.responseText === "inv_img") {
      alert("error", "Only JPG and PNG images are allowed!");
    } else if (this.responseText === "inv_size") {
      alert("error", "Image should be less than 2MB!");
    } else if (this.responseText === "upd_failed") {
      alert("error", "Image upload failed. Server Down");
    } else {
      alert("success", "New Destination added");

      // Clear the form inputs
      clearForm();

      // Refresh destinations list
      get_destinations();
    }
  };

  xhr.send(data);
}

// Fetch and display destinations
function get_destinations() {
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "ajax/latest_crud.php", true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

  xhr.onload = function () {
    // Update the destinations container with fetched data
    document.getElementById("destination-data").innerHTML = this.responseText;
  };

  xhr.send("get_destinations"); // Key to trigger fetching destinations
}

// Remove a destination
function remDestination(id) {
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "ajax/latest_crud.php", true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

  xhr.onload = function () {
    // Handle the response from the backend
    if (this.responseText == 1) {
      alert("success", "Destination removed successfully");
      get_destinations(); // Refresh the destinations list
    } else {
      alert("error", "Failed to remove destination. Server Down");
    }
  };

  xhr.send("rem_destination=" + id); // Send the destination ID to delete
}

// Function to clear the form inputs
function clearForm() {
  location_image.value = "";
  destination_location.value = "";
  destination_description.value = "";
  destination_old_price.value = "";
  destination_new_price.value = "";
  destination_duration.value = "";
}

// Load destinations on page load
window.onload = () => {
  get_destinations();
};
