// Function to add or update a package
document.addEventListener("DOMContentLoaded", function () {
  let package_s_form = document.getElementById("package_s_form");
  let package_image_inp = document.getElementById("package_image_inp");
  let package_name = document.getElementById("package_name");
  let package_desc = document.getElementById("package_desc");

  // Handle form submission for adding or editing packages
  package_s_form.addEventListener("submit", function (e) {
    e.preventDefault();
    add_package();
  });

  // Function to add or update a package
  function add_package() {
    let data = new FormData();

    // Append all form data
    data.append("package_image", package_image_inp.files[0]); // File input
    data.append("package_name", package_name.value); // Package name
    data.append("package_desc", package_desc.value); // Package description
    data.append("add_package", ""); // Key to identify backend operation

    // Create an AJAX request
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "ajax/package_crud.php", true);

    xhr.onload = function () {
      let myModal = new bootstrap.Modal(
        document.getElementById("package-modal")
      );
      myModal.hide();

      if (this.responseText === "inv_img") {
        alert("error", "Only JPG and PNG images are allowed!");
      } else if (this.responseText === "inv_size") {
        alert("error", "Image should be less than 2MB!");
      } else if (this.responseText === "upd_failed") {
        alert("error", "Image upload failed. Server Down");
      } else {
        alert("success", "New package added");

        // Refresh packages list
        get_packages();
      }
    };

    xhr.send(data);
  }
});

// Fetch and display packages
function get_packages() {
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "ajax/package_crud.php", true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

  xhr.onload = function () {
    document.getElementById("package-data").innerHTML = this.responseText;
  };

  xhr.send("get_package");
}

// Remove a package
function rempackage(id) {
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "ajax/package_crud.php", true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

  xhr.onload = function () {
    console.log(this.responseText); // Debug response
    if (this.responseText == 1) {
      // Find and remove the corresponding card from the DOM
      let packageCard = document.querySelector(`[data-id='${id}']`);
      if (packageCard) {
        packageCard.remove();
      }
      alert("success", "Package removed successfully");
    } else {
      alert("error", "Failed to remove package. Server Down");
    }
  };

  xhr.send("rem_package=" + id);
}

// Load packages on page load
window.onload = () => {
  get_packages();
};
