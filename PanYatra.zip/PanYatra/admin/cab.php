<?php
require('inc/essentials.php');
require('inc/db_config.php');
adminLogin();

// Check if 'seen' or 'del' is set in the URL
if (isset($_GET['seen'])) {
    $frm_data = filteration($_GET);

    if ($frm_data['seen'] == 'all') {
        // Handle 'seen' all case
        $q = "UPDATE `cabs` SET `seen` = ?";
        $value = [1];
        if (update($q, $value, 'i')) {
            alert('success', 'Marked all as read');
        } else {
            alert('error', 'Operation failed');
        }
    } else {
        $q = "UPDATE `cabs` SET `seen` = ? WHERE `id` = ?";
        $value = [1, $frm_data['seen']];
        if (update($q, $value, 'ii')) {
            alert('success', 'Marked as read');
        } else {
            alert('error', 'Operation failed');
        }
    }

    // Redirect to remove 'seen' parameter from the URL
    header("Location: cab.php");
    exit;
}

if (isset($_GET['del'])) {
    $frm_data = filteration($_GET);

    // Delete all records
    if ($frm_data['del'] == 'all') {
        $q = "DELETE FROM `cabs`";
        if (mysqli_query($con, $q)) {
            alert('success', 'All data deleted');
        } else {
            alert('error', 'Operation failed');
        }
    } else {
        // Delete specific record
        $q = "DELETE FROM `cabs` WHERE `id` = ?";
        $value = [$frm_data['del']];
        if (delete($q, $value, 'i')) {
            alert('success', 'Data deleted');
        } else {
            alert('error', 'Operation failed');
        }
    }

    // Redirect to remove 'del' parameter from the URL
    header("Location: cab.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Cab Bookings</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.6/css/jquery.dataTables.css">
    <script type="text/javascript" charset="utf8" src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <?php require('inc/link.php'); ?>
</head>

<body class="bg-light">

    <?php require('inc/header.php'); ?>

    <div class="container-fluid" id="main-content">
        <div class="row">
            <div class="col-lg-10 ms-auto p-4 overflow-hidden">
                <h3 class="mb-4">Cab Bookings</h3>

                <!-- Admin Actions -->
                <div class="card border-0 shadow mb-4">
                    <div class="card-body">
                        <div class="text-end mb-4">
                            <a href="?seen=all" class="btn btn-dark rounded-pill shadow-none btn-sm">
                                <i class="bi bi-check2-all"></i> Mark all read
                            </a>
                            <a href="?del=all" class="btn btn-danger rounded-pill shadow-none btn-sm">
                                <i class="bi bi-trash3"></i> Delete All
                            </a>
                        </div>

                        <!-- Cab Data Table -->
                        <div class="table-responsive-md" style="height:450px; overflow-y: scroll;">
                            <table id="cabTable" class="table table-hover border">
                                <thead class="sticky-top">
                                    <tr class="bg-dark text-light">
                                        <th scope="col">ID</th>
                                        <th scope="col">Cab</th>
                                        <th scope="col">Pickup Location</th>
                                        <th scope="col">Drop Location</th>
                                        <th scope="col">Pickup Date</th>
                                        <th scope="col">Pickup Time</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Phone</th>
                                        <th scope="col">Promo Code</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Fetch bookings data
                                    $q = "SELECT * FROM `cabs` ORDER BY `id` DESC";
                                    $data = mysqli_query($con, $q);
                                    $i = 1;

                                    while ($row = mysqli_fetch_assoc($data)) {
                                        $seen = '';
                                        if ($row['seen'] != 1) {
                                            $seen = "<a href='?seen={$row['id']}' class='btn btn-sm rounded-pill btn-primary'>Mark as read</a> <br>";
                                        }
                                        $seen .= "<a href='?del={$row['id']}' class='btn btn-sm rounded-pill btn-danger mt-2'>Delete</a>";
                                        echo "
                                        <tr>
                                            <td>$i</td>
                                            <td>{$row['Car_Select']}</td>
                                            <td>{$row['pickup_location']}</td>
                                            <td>{$row['drop_location']}</td>
                                            <td>{$row['pickup_date']}</td>
                                            <td>{$row['pickup_time']}</td>
                                            <td>{$row['full_name']}</td>
                                            <td>{$row['email']}</td>
                                            <td>{$row['phone']}</td>
                                            <td>{$row['promo_code']}</td>
                                            <td>$seen</td>
                                        </tr>";
                                        $i++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require('inc/script.php'); ?>

    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.6/js/jquery.dataTables.js"></script>

    <script>
        $(document).ready(function() {
            $('#cabTable').DataTable();
        });
    </script>

</body>

</html>
