<div class="container-fluid bg-dark text-white p-3 d-flex align-items-center justify-content-between sticky-top">
        <h3 class="mb-0 h-font">PANYATRA</h3>
        <a href="logout.php" class="btn btn-light btn-sm">LOG-OUT</a>
    </div>

    <div class="col-lg-2 bg-dark border-top border-3 border-secondary" id="dashboard-menu">
        <nav class="navbar navbar-expand-lg navbar-dark rounded">
            <div class="container-fluid flex-lg-column align-items-stretch">
                <h4 class="mt-2 text-light">ADMIN PANEL</h4>
                <button class="navbar-toggler shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#adminDropdown" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse flex-column align-items-stretch mt-2" id="adminDropdown">
                    <ul class="nav nav-pills flex-column">
                        <li class="nav-item">
                            <a class="nav-link text-white" href="dashboard.php">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="vehicles .php">Vehicles </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="features_facilities.php">Feature & Facilities</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="carousel.php">Carousel</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="settings.php">Settings</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="contact_us.php">Contact US</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="cab.php">Cab</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="customized.php">Customized Package</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="package_booking.php">Packages Booking</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="latest_trip.php">Latest Trip</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="package.php">Packages</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="more_location.php">More Location</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="hotel.php">Hotel</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>