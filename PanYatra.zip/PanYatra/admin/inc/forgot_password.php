<?php
require($_SERVER['DOCUMENT_ROOT'] . '/PanYatra/admin/inc/essentials.php');
require($_SERVER['DOCUMENT_ROOT'] . '/PanYatra/admin/inc/db_config.php');

if (isset($_POST['reset_request'])) {
    $frm_data = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

    if (isset($frm_data['email'])) {
        $email = $frm_data['email'];

        // Check if the email exists in the database
        $query = "SELECT * FROM `admin_cred` WHERE `admin_email` = ?";
        $res = select($query, [$email], "s");

        if ($res->num_rows == 1) {
            $token = bin2hex(random_bytes(50)); // Generate a secure random token
            $reset_link = "http://yourwebsite.com/reset_password.php?token=" . $token;

            // Save the token in the database
            $update_query = "UPDATE `admin_cred` SET `reset_token` = ? WHERE `admin_email` = ?";
            $update_res = update($update_query, [$token, $email], "ss");

            if ($update_res) {
                // Send reset email
                $subject = "Password Reset Request";
                $message = "Click the link below to reset your password:\n\n" . $reset_link;
                $headers = "From: noreply@yourwebsite.com";

                if (mail($email, $subject, $message, $headers)) {
                    alert('success', 'A reset link has been sent to your email.');
                } else {
                    alert('error', 'Failed to send email. Try again later.');
                }
            } else {
                alert('error', 'Failed to generate reset link. Try again later.');
            }
        } else {
            alert('error', 'No account found with this email.');
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <?php require($_SERVER['DOCUMENT_ROOT'] . '/PanYatra/admin/inc/link.php'); ?>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-lg-4">
                <form method="POST">
                    <h3 class="text-center">Reset Password</h3>
                    <div class="form-group mb-3">
                        <input type="email" name="email" class="form-control shadow-none" placeholder="Enter your email" required>
                    </div>
                    <button type="submit" name="reset_request" class="btn btn-primary btn-block shadow-none">Send Reset Link</button>
                </form>
            </div>
        </div>
    </div>
    <?php require($_SERVER['DOCUMENT_ROOT'] . '/PanYatra/admin/inc/script.php'); ?>
</body>
</html>
