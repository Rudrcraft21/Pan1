<?php
require('inc/essentials.php');
require('inc/db_config.php');

session_start();
session_regenerate_id(true);

// Check if user is already logged in
if (isset($_SESSION['adminLogin']) && $_SESSION['adminLogin'] == true) {
    redirect('dashboard.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login & Register Panel</title>
    <?php require('inc/link.php'); ?>
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
        /* Background styling */
        body {
            background: linear-gradient(45deg, #343a40, #17a2b8);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Card styling */
        .auth-card {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            width: 400px;
            overflow: hidden;
            position: relative;
        }

        .auth-card .card-header {
            background: #17a2b8;
            color: #fff;
            text-align: center;
            padding: 1.5rem 1rem;
            font-size: 1.5rem;
            font-weight: bold;
        }

        .auth-card .card-body {
            padding: 2rem;
        }

        .btn-primary {
            background-color: #17a2b8;
            border: none;
        }

        .btn-primary:hover {
            background-color: #138496;
        }

        .form-control {
            border-radius: 50px;
            padding: 0.75rem 1rem;
        }

        .btn-block {
            border-radius: 50px;
            padding: 0.5rem 0;
        }

        .toggle-link {
            color: #17a2b8;
            cursor: pointer;
        }

        .toggle-link:hover {
            text-decoration: underline;
        }

        .hidden {
            display: none;
        }
    </style>
</head>

<body>
    <!-- Auth Card -->
    <div class="auth-card animate__animated animate__fadeIn">
        <div class="card-header" id="auth-title">Admin Login Panel</div>
        <div class="card-body">
            <!-- Login Form -->
            <form id="login-form" method="POST">
                <div class="form-group mb-4">
                    <input type="text" name="admin_name" class="form-control shadow-none" placeholder="Admin Name" required>
                </div>
                <div class="form-group mb-4">
                    <input type="password" name="admin_pass" class="form-control shadow-none" placeholder="Password"
                        required>
                </div>
                <button type="submit" name="login" class="btn btn-primary btn-block shadow-none" style="width:100px;">LOGIN</button>
                <div class="text-center mt-3">
                    <span class="toggle-link" onclick="showRegisterForm()">Register</span> |
                    <a href="inc/forgot_password.php" class="toggle-link">Forgot Password?</a>
                </div>
            </form>

            <!-- Register Form -->
            <form id="register-form" class="hidden" method="POST">
                <div class="form-group mb-3">
                    <input type="text" name="admin_name" class="form-control shadow-none" placeholder="Admin Name" required>
                </div>
                <div class="form-group mb-3">
                    <input type="email" name="admin_email" class="form-control shadow-none" placeholder="Email" required>
                </div>
                <div class="form-group mb-3">
                    <input type="text" name="admin_mobile" class="form-control shadow-none" placeholder="Mobile Number" required>
                </div>
                <div class="form-group mb-3">
                    <input type="password" name="admin_pass" class="form-control shadow-none" placeholder="Password" required>
                </div>
                <div class="form-group mb-4">
                    <input type="password" name="admin_pass_confirm" class="form-control shadow-none" placeholder="Confirm Password" required>
                </div>

                <button type="submit" name="register" class="btn btn-primary btn-block shadow-none" style="width:100px;">REGISTER</button>
                <span class="toggle-link" onclick="showLoginForm()">Back to Login</span>
            </form>
        </div>
    </div>

    <?php
    if (isset($_POST['login'])) {
        $frm_data = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

        // Check if admin_name and admin_pass are set
        if (isset($frm_data['admin_name']) && isset($frm_data['admin_pass'])) {
            $query = "SELECT * FROM `admin_cred` WHERE `admin_name` = ?";
            $values = [$frm_data['admin_name']];

            $res = select($query, $values, "s");

            if ($res->num_rows == 1) {
                $row = mysqli_fetch_assoc($res);

                // Verify the password with the hashed password stored in the database
                if (password_verify($frm_data['admin_pass'], $row['admin_pass'])) {
                    $_SESSION['adminLogin'] = true;
                    $_SESSION['adminId'] = $row['sr_no'];
                    redirect('dashboard.php');
                } else {
                    echo '<script>alert("Login failed - Invalid Credentials!");</script>';
                }
            } else {
                echo '<script>alert("Login failed - Invalid Credentials!");</script>';
            }
        }
    }


    if (isset($_POST['register'])) {
        // Sanitize form data
        $frm_data = filteration($_POST);

        // Check if password and confirm password match
        if (!isset($frm_data['admin_pass_confirm'])) {
            alert('error', 'Confirm Password field is missing.');
        } elseif ($frm_data['admin_pass'] !== $frm_data['admin_pass_confirm']) {
            alert('error', 'Password and Confirm Password do not match!');
        } else {
            // Hash the password for security
            $hashed_pass = password_hash($frm_data['admin_pass'], PASSWORD_DEFAULT);

            // Query to insert data into the admin_cred table
            $q = "INSERT INTO `admin_cred` (`admin_name`, `admin_email`, `admin_mobile`, `admin_pass`) VALUES (?, ?, ?, ?)";
            $value = [$frm_data['admin_name'], $frm_data['admin_email'], $frm_data['admin_mobile'], $hashed_pass];

            // Assuming you have an 'insert' function that handles database insertion
            $res = insert($q, $value, 'ssss');

            if ($res == 1) {
                alert('success', 'Registration Successful!');
                echo '<script>window.location = "index.php";</script>';
                exit();
            } else {
                alert('error', 'Server Down! Please try again later.');
            }
        }
    }
    ?>

    <?php require('inc/script.php'); ?>
    <script>
        // Function to toggle forms
        function showRegisterForm() {
            document.getElementById('login-form').classList.add('hidden');
            document.getElementById('register-form').classList.remove('hidden');
            document.querySelector('.auth-card').classList.add('animate__fadeIn');
            document.getElementById('auth-title').innerText = "Admin Register Panel";
        }

        function showLoginForm() {
            document.getElementById('register-form').classList.add('hidden');
            document.getElementById('login-form').classList.remove('hidden');
            document.querySelector('.auth-card').classList.add('animate__fadeIn');
            document.getElementById('auth-title').innerText = "Admin Login Panel";
        }
    </script>
</body>

</html>