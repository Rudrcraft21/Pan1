<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PANYATRA - Travel companies</title>
    <?php require('inc/link.php'); ?>
    <style>
        :root {
            --primary-color: #1d3557;
            --secondary-color: #f4a261;
            --accent-color: #2a9d8f;
            --dark-color: #264653;
            --light-color: #fefae0;
        }

        body {
            background-color: var(--light-color);
        }

        .h-line {
            width: 80px;
            height: 4px;
            margin: 0 auto;
        }

        .btn-dark {
            background-color: var(--primary-color);
            color: var(--light-color);
            transition: all 0.3s;
        }

        .btn-dark:hover {
            background-color: var(--secondary-color);
            color: #fff;
        }

        .btn-warning {
            background-color: var(--secondary-color);
            color: var(--dark-color);
            transition: all 0.3s;
        }

        .btn-warning:hover {
            background-color: var(--accent-color);
            color: var(--light-color);
        }

        .pop:hover {
            border-top-color: var(--secondary-color) !important;
            transform: scale(1.05);
            transition: all 0.3s;
        }

        .card-title {
            font-size: 1.25rem;
            font-weight: bold;
        }

        .swiper-slide {
            background-color: var(--light-color);
            border-radius: 8px;
            padding: 15px;
        }

        .chatbot {
            width: 50px;
            height: 50px;
            background-color: var(--accent-color);
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            animation: bounce 2s infinite;
        }

        @keyframes bounce {

            0%,
            20%,
            50%,
            80%,
            100% {
                transform: translateY(0);
            }

            40% {
                transform: translateY(-10px);
            }

            60% {
                transform: translateY(-5px);
            }
        }

        .chat-popup {
            display: none;
            position: fixed;
            bottom: 80px;
            right: 20px;
            background: var(--light-color);
            border: 1px solid var(--accent-color);
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            z-index: 10;
        }

        .chat-popup.active {
            display: block;
            animation: fadeIn 0.5s;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* tour card css */
        .card-img-top {
            height: 200px;
            /* Adjust as per your design */
            object-fit: cover;
        }

        .card {
            height: 100%;
        }

        /* modal css */
        /* General Modal Styles */
        .modal-content {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: none;
        }

        /* Modal Header Styling */
        .modal-header {
            background: linear-gradient(90deg, #f4a261, #2a9d8f);
            color: #fff;
            border-radius: 10px 10px 0 0;
            padding: 15px;
        }

        /* Modal Title Styling */
        .modal-header .modal-title {
            font-size: 1.5rem;
            font-weight: bold;
        }

        /* Close Button Styling */
        .btn-close {
            color: #fff;
            opacity: 1;
        }

        /* Modal Body Styling */
        .modal-body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #fff;
            color: #333;
        }

        /* Day Title (Headings) Styling */
        .day-title {
            font-weight: bold;
            color: #264653;
            margin-top: 20px;
            border-bottom: 2px solid #f4a261;
            display: inline-block;
            padding-bottom: 5px;
        }

        /* Styling for Important Notes */
        .important,
        .highlight {
            background-color: #ffe8a1;
            border-left: 5px solid #f4a261;
            padding: 10px;
            margin-top: 10px;
            font-weight: bold;
            color: #e76f51;
        }

        /* Styling for Modal Footer */
        .modal-footer {
            background-color: #f1f1f1;
            padding: 15px;
            text-align: center;
        }

        /* Modal Button Styling */
        .btn-secondary {
            background-color: #264653;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 1rem;
        }

        .btn-secondary:hover {
            background-color: #2a9d8f;
        }

        /* Additional Styling for Meal/Note Text */
        .modal-body p {
            margin-bottom: 15px;
            line-height: 1.5;
        }

        /* Responsive Design for Modals */
        @media (max-width: 768px) {
            .modal-dialog {
                max-width: 90%;
            }

            .modal-body {
                padding: 10px;
            }

            .modal-footer {
                padding: 10px;
            }

            .btn-secondary {
                font-size: 0.9rem;
                padding: 8px 16px;
            }
        }
    </style>
</head>

<body>

    <!-- Header Section -->
    <?php require('inc/header.php'); ?>

    <!-- Packages Section -->
    <div class="container my-5">
        <h2 class="fw-bold h-font text-center h-font">EXCLUSIVE TRAVEL PACKAGES</h2>
        <div class="h-line bg-dark"></div>
        <p class="text-center mt-3">Explore our handpicked travel packages designed to provide you with the ultimate experience.</p>

        <div class="row g-4 mt-4">
            <?php
            // Adjust query to fetch only 3 latest packages by created_at
            // Modify the selectAll function to accept the query properly

            $package_r = selectAll('package', 'ORDER BY id DESC LIMIT 3'); // Ensure this is passed correctly to the function
            $path = PACKAGE_IMG_PATH; // Define the base path for images

            // Check if any packages exist
            if (mysqli_num_rows($package_r) > 0) {
                while ($row = mysqli_fetch_assoc($package_r)) {
                    // Dynamic Modal ID and Data
                    $modalId = "packageModal" . $row['id']; // Unique ID for each package's modal
                    $packageName = $row['package_name'];
                    $packageDesc = $row['package_desc'];
                    $packageImage = $row['image'];

                    // Display each package in a card
                    echo <<<HTML
                <div class="col-lg-4 col-md-6">
                    <div class="card shadow border-top border-4 border-warning pop h-100">
                        <img src="{$path}{$packageImage}" class="card-img-top img-fluid" alt="{$packageName}">
                        <div class="card-body d-flex flex-column text-center">
                            <h5 class="card-title">{$packageName}</h5>
                            <p>{$packageDesc}</p>
                            <div class="mt-auto">
                                <!-- Trigger the modal -->
                                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#{$modalId}">
                                    View Details
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Dynamic Modal for each package -->
                <div class="modal fade" id="{$modalId}" tabindex="-1" aria-labelledby="{$modalId}Label" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="{$modalId}Label">{$packageName} Details</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <h5>Package Description:</h5>
                                <p>{$packageDesc}</p>
                                <h5>Itinerary:</h5>
                                <ul>
                                    <li>Day 1: Arrival and check-in</li>
                                    <li>Day 2: Sightseeing</li>
                                    <li>Day 3: Adventure Activities</li>
                                </ul>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" onclick="window.location.href='booking_form.php'">Book Now</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
                HTML;
                }
            } else {
                // No packages found
                echo '<p class="text-center">No travel packages available at the moment. Please check back later.</p>';
            }
            ?>
        </div>

        <div class="col-lg-12 text-center mt-5">
            <a href="mainpackage.php" class="btn btn-sm btn-warning text-white">Explore More Packages &gt;&gt;&gt;</a>
        </div>
    </div>



    <!--Customised Package -->
    <!-- Customised Package Section -->
    <div class="container my-5">
        <h2 class="fw-bold text-center h-font">CUSTOMISE YOUR TRAVEL PACKAGE</h2>
        <div class="h-line bg-dark"></div>
        <p class="text-center mt-3">Can't find a package that suits your needs? Create your own personalized travel plan, and we’ll handle the rest.</p>

        <div class="row g-4 mt-4">
            <!-- Customisation Form -->
            <div class="col-lg-6">
                <form method="POST" class="shadow p-4 rounded bg-white">
                    <h4 class="fw-bold mb-4">Tell us your preferences</h4>

                    <div class="mb-3">
                        <label for="name" class="form-label">Your Name</label>
                        <input type="text" id="name" name="name" class="form-control" placeholder="Enter your name" required>
                    </div>

                    <div class="mb-3">
                        <label for="name" class="form-label">Phone No.</label>
                        <input type="text" id="name" name="phone" class="form-control" placeholder="Enter your name" required>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" id="email" name="email" class="form-control" placeholder="Enter your email" required>
                    </div>

                    <div class="mb-3">
                        <label for="destinations" class="form-label">Preferred Destinations</label>
                        <input type="text" id="destinations" name="destinations" class="form-control" placeholder="E.g., Manali, Shimla, Kerala" required>
                    </div>

                    <div class="mb-3">
                        <label for="travelDates" class="form-label">Travel Dates</label>
                        <input type="date" id="travelDates" name="travelDates" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="budget" class="form-label">Your Budget (₹)</label>
                        <input type="number" id="budget" name="budget" class="form-control" placeholder="Enter your budget" required>
                    </div>

                    <div class="mb-3">
                        <label for="message" class="form-label">Additional Requests</label>
                        <textarea id="message" name="message" class="form-control" rows="4" placeholder="Enter any specific requirements"></textarea>
                    </div>

                    <button type="submit" name="send" class="btn btn-warning w-100">Submit Request</button>
                </form>
            </div>


            <!-- Customised Package Benefits -->
            <div class="col-lg-6">
                <div class="text-center">
                    <img src="images/custom-package.jpg" class="img-fluid rounded shadow-lg border border-warning" alt="Customised Package">
                </div>
                <h4 class="fw-bold mt-4 text-center text-primary">Why Choose a Customised Package?</h4>
                <p class="mt-3 text-justify">
                    We understand that every traveler is unique. With our customised packages, you can design your dream vacation with the destinations, activities, and budget that suit you best. Let us handle the details while you focus on making unforgettable memories.
                </p>
                <ul class="list-unstyled mt-3">
                    <li class="mb-3 d-flex align-items-start">
                        <i class="bi bi-check-circle-fill text-warning me-3 fs-5"></i>
                        <div>
                            <strong class="text-dark">Tailored Itinerary:</strong>
                            <span class="d-block">Craft a personalized travel plan that fits your schedule, interests, and desired pace of travel.</span>
                        </div>
                    </li>
                    <li class="mb-3 d-flex align-items-start">
                        <i class="bi bi-check-circle-fill text-warning me-3 fs-5"></i>
                        <div>
                            <strong class="text-dark">Flexible Budget:</strong>
                            <span class="d-block">We provide a variety of options to suit your financial preferences without compromising quality and comfort.</span>
                        </div>
                    </li>
                    <li class="mb-3 d-flex align-items-start">
                        <i class="bi bi-check-circle-fill text-warning me-3 fs-5"></i>
                        <div>
                            <strong class="text-dark">Exclusive Activities:</strong>
                            <span class="d-block">Immerse yourself in experiences tailored to your interests, such as:</span>
                            <ul class="ms-4">
                                <li>Adventure sports: paragliding, river rafting, and trekking.</li>
                                <li>Local culture exploration: traditional dance, music, and festivals.</li>
                                <li>Food tours: savor regional delicacies and cooking classes.</li>
                                <li>Eco-tourism: nature walks, wildlife safaris, and bird watching.</li>
                                <li>Luxury retreats: spa sessions, yacht cruises, and private dinners.</li>
                            </ul>
                        </div>
                    </li>
                    <li class="mb-3 d-flex align-items-start">
                        <i class="bi bi-check-circle-fill text-warning me-3 fs-5"></i>
                        <div>
                            <strong class="text-dark">Dedicated Support:</strong>
                            <span class="d-block">Enjoy 24/7 assistance throughout your journey, ensuring a hassle-free experience from start to finish.</span>
                        </div>
                    </li>
                    <li class="mb-3 d-flex align-items-start">
                        <i class="bi bi-check-circle-fill text-warning me-3 fs-5"></i>
                        <div>
                            <strong class="text-dark">Custom Travel Groups:</strong>
                            <span class="d-block">Travel solo, as a couple, or with a group of friends or family. We make arrangements to match your group's specific needs.</span>
                        </div>
                    </li>
                </ul>
                <div class="text-center mt-4">
                    <a href="mainpackage.php" class="btn btn-lg btn-warning text-white px-5 shadow-sm">Start Planning Now</a>
                </div>
            </div>
        </div>
    </div>
    </div>

    <!-- Search Section -->
    <div class="container my-5">
        <div class="bg-white rounded shadow p-4">
            <form class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Departure</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="bi bi-taxi-front"></i></span>
                        <input type="text" class="form-control" placeholder="Booking From">
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Destination</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="bi bi-taxi-front"></i></span>
                        <input type="text" class="form-control" placeholder="Booking To">
                    </div>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Departure Date</label>
                    <input type="date" class="form-control">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Return Date</label>
                    <input type="date" class="form-control">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Passengers</label>
                    <input type="number" class="form-control" min="1" placeholder="1">
                </div>
                <div class="col-12 text-center mt-3">
                    <button type="submit" class="btn btn-dark">Search</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Services Section -->
    <div class="container my-5">
        <h2 class="fw-bold text-center h-font">OUR SERVICES</h2>
        <div class="h-line bg-dark"></div>
        <p class="text-center mt-3">We offer a wide range of travel services tailored to meet your needs.</p>

        <div class="row g-4 mt-4">
            <!-- Service Card 1 -->
            <div class="col-lg-3 col-md-6">
                <div class="card shadow border-top border-4 border-warning pop">
                    <div class="card-body text-center">
                        <i class="bi bi-airplane fs-1 text-secondary mb-3"></i>
                        <h5 class="card-title">Flight Booking</h5>
                        <p>Book flights worldwide at the best prices and enjoy a hassle-free travel experience.</p>
                    </div>
                </div>
            </div>

            <!-- Service Card 2 -->
            <div class="col-lg-3 col-md-6">
                <div class="card shadow border-top border-4 border-warning pop">
                    <div class="card-body text-center">
                        <i class="bi bi-building fs-1 text-secondary mb-3"></i>
                        <h5 class="card-title">Hotel Booking</h5>
                        <p>Reserve your stay from a variety of hotels globally, with exclusive deals.</p>
                    </div>
                </div>
            </div>

            <!-- Service Card 3 -->
            <div class="col-lg-3 col-md-6">
                <div class="card shadow border-top border-4 border-warning pop">
                    <div class="card-body text-center">
                        <i class="bi bi-train-front fs-1 text-secondary mb-3"></i>
                        <h5 class="card-title">Train Booking</h5>
                        <p>Plan your rail journeys with convenient train booking options at your fingertips.</p>
                    </div>
                </div>
            </div>

            <!-- Service Card 4 -->
            <div class="col-lg-3 col-md-6">
                <div class="card shadow border-top border-4 border-warning pop">
                    <div class="card-body text-center">
                        <i class="bi bi-taxi-front fs-1 text-secondary mb-3"></i>
                        <h5 class="card-title">Cab Booking</h5>
                        <p>Book reliable cabs for your city tours and long-distance journeys with ease.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php require('inc/footer.php'); ?>


    <!-- Modal -->
    <!-- Modal for Shimla-Manali Tour Package -->
    <div class="modal fade" id="tourModal" tabindex="-1" aria-labelledby="tourModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h5 class="modal-title" id="tourModalLabel">Shimla-Manali Tour Package</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <!-- Modal Body -->
                <div class="modal-body">
                    <h5 class="day-title">Day 1: Chandigarh - Shimla (130km | 3-4 hrs)</h5>
                    <p>Upon arrival at Chandigarh, you’ll be driven to Shimla, the Queen of Hills. After a 3-4 hour journey, check in to the hotel and enjoy an overnight stay.</p>

                    <h5 class="day-title">Day 2: Shimla-Kufri Local Sightseeing</h5>
                    <p>Post breakfast, head to Kufri, a popular spot known for its scenic beauty and activities (on direct payment basis). Visit attractions like the Mall, Ridge, Christ Church, and more. End the day with dinner and overnight stay.</p>
                    <p><strong>Meals:</strong> Tea + Breakfast + Dinner</p>

                    <h5 class="day-title">Day 3: Shimla - Kullu - Manali (280 km)</h5>
                    <p>On the way to Manali, visit Sunder Nagar Lake, Pandoh Dam, Kullu Valley, and enjoy river rafting (optional). Check-in at the hotel in Manali for an overnight stay.</p>
                    <p><strong>Meals:</strong> Tea + Breakfast + Dinner</p>

                    <h5 class="day-title">Day 4: Manali - Solang Valley - Atal Tunnel - Sissu</h5>
                    <p>Spend the day at Solang Valley indulging in adventure sports like paragliding, zorbing, cable cars, and ATV rides (direct payment). Visit Atal Tunnel and Sissu before heading back to the hotel.</p>
                    <div class="important">Note: Rohtang Pass access depends on weather conditions and NGT permissions. Additional charges may apply.</div>
                    <p><strong>Meals:</strong> Tea + Breakfast + Dinner</p>

                    <h5 class="day-title">Day 5: Manali - Bijli Mahadev - Kasol</h5>
                    <p>After breakfast, visit Bijli Mahadev, a sacred temple located at an altitude of 2,460m in Kullu Valley. Return to Manali for dinner and overnight stay.</p>
                    <p><strong>Meals:</strong> Tea + Breakfast + Dinner</p>

                    <h5 class="day-title">Day 6: Manali Local Sightseeing</h5>
                    <p>Explore attractions in Manali like Hadimba Temple, Mall Road, and local markets. End the day with a cozy overnight stay at the hotel.</p>
                    <p><strong>Meals:</strong> Tea + Breakfast + Dinner</p>

                    <h5 class="day-title">Day 7: Manali - Kullu Drop (40 km)</h5>
                    <p>Check out from the hotel and proceed to Kullu for your return journey. Bid farewell to the serene hills and take back beautiful memories.</p>
                    <p><strong>Meals:</strong> Tea + Breakfast</p>
                </div>
                <!-- Modal Footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="window.location.href='booking_form.php'">Book Now</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Manali-Kullu-Shimla Tour -->
    <div class="modal fade" id="tourDetailsModal" tabindex="-1" aria-labelledby="tourDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="tourDetailsModalLabel">Manali-Kullu-Shimla Tour (5 Nights/6 Days)</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h5>1st Day: Chandigarh - Kullu - Manali (305 km | 8-9 hrs)</h5>
                    <p>Arrival at Chandigarh and proceed to Manali. Enjoy scenic views at Sunder Nagar Lake, Shawl Factory, Pandoh Dam, and Kullu Valley. Activities like river rafting are optional. Overnight stay in Manali.</p>
                    <p><strong>Meal:</strong> Dinner</p>

                    <h5>2nd Day: Manali - Local Sightseeing</h5>
                    <p>Visit Hadimba Temple, Tibetan Monastery, Vashisht Hot Springs, Mall Road, and the local market of Manali. Enjoy a comfortable overnight stay.</p>
                    <p><strong>Meal:</strong> Morning Tea + Breakfast + Dinner</p>

                    <h5>3rd Day: Manali - Solang Valley</h5>
                    <p>Indulge in adventure sports like paragliding, zorbing, and ziplining at Solang Valley. Visit Rohtang Pass (optional) and return to the hotel for an overnight stay.</p>
                    <div class="highlight">Note: Rohtang Pass access depends on weather conditions. Additional charges apply.</div>
                    <p><strong>Meal:</strong> Morning Tea + Breakfast + Dinner</p>

                    <h5>4th Day: Manali - Shimla (280 km | 10 hrs)</h5>
                    <p>Travel from Manali to Shimla and check into the hotel. Visit the local markets of Shimla and enjoy an overnight stay.</p>
                    <p><strong>Meal:</strong> Morning Tea + Breakfast + Dinner</p>

                    <h5>5th Day: Shimla - Kufri - Local Sightseeing</h5>
                    <p>Enjoy sightseeing in Kufri, including attractions like Green Valley, Indira Tourist Park, and Mini Zoo. Visit popular spots like Christ Church and Mall Road in Shimla. Overnight stay at the hotel.</p>
                    <p><strong>Meal:</strong> Morning Tea + Breakfast + Dinner</p>

                    <h5>6th Day: Shimla - Chandigarh Drop (130 km | 3-4 hrs)</h5>
                    <p>Check out and head to Chandigarh for the return journey. Bid farewell to the serene hills with beautiful memories.</p>
                    <p><strong>Meal:</strong> Morning Tea + Breakfast</p>

                    <p class="text-center mt-3"><strong>END OF TOUR WITH BEAUTIFUL MEMORIES</strong></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="window.location.href='booking_form.php'">Book Now</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Manali with Kasol Tour -->
    <div class="modal fade" id="kasolTourModal" tabindex="-1" aria-labelledby="kasolTourModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="kasolTourModalLabel">Manali with Kasol Tour (5 Nights/6 Days)</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h5>1st Day: Chandigarh - Kullu - Manali (305 km | 8-9 hrs)</h5>
                    <p>Arrival at Chandigarh and proceed to Manali. Visit scenic spots like Shawl Factory, Sunder Nagar Lake, and Kullu Valley. Optional activities include river rafting. Overnight stay in Manali.</p>
                    <p><strong>Meal:</strong> Dinner</p>

                    <h5>2nd Day: Manali - Local Sightseeing</h5>
                    <p>Explore Hadimba Temple, Tibetan Monastery, Vashisht Hot Springs, and Mall Road. Overnight stay in Manali.</p>
                    <p><strong>Meal:</strong> Morning Tea + Breakfast + Dinner</p>

                    <h5>3rd Day: Manali - Solang Valley</h5>
                    <p>Explore adventure activities at Solang Valley, including paragliding, zorbing, and ziplining. Return to Manali for overnight stay.</p>
                    <div class="highlight">Note: Rohtang Pass access depends on weather conditions. Additional charges apply.</div>
                    <p><strong>Meal:</strong> Morning Tea + Breakfast + Dinner</p>

                    <h5>4th Day: Manali - Kasol (75 km)</h5>
                    <p>Travel from Manali to Kasol. Visit Kheerganga, Tosh, and Chalal for scenic views and explore the local culture. Return to the hotel for overnight stay.</p>
                    <p><strong>Meal:</strong> Morning Tea + Breakfast + Dinner</p>

                    <h5>5th Day: Kasol - Manali</h5>
                    <p>Return to Manali from Kasol for a day of leisure and relaxation. Enjoy local sightseeing, shopping, and a comfortable overnight stay.</p>
                    <p><strong>Meal:</strong> Morning Tea + Breakfast + Dinner</p>

                    <h5>6th Day: Manali - Chandigarh Drop</h5>
                    <p>Head to Chandigarh after breakfast, bidding farewell to the mountains.</p>
                    <p><strong>Meal:</strong> Morning Tea + Breakfast</p>

                    <p class="text-center mt-3"><strong>END OF TOUR WITH BEAUTIFUL MEMORIES</strong></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="window.location.href='booking_form.php'">Book Now</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <?php
    if (isset($_POST['send'])) {
        $frm_data = filteration($_POST);

        // Prepare the SQL query for insertion
        $q = "INSERT INTO `customized_packages` (`name`, `phone`, `email`, `destinations`, `travel_dates`, `budget`, `message`) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $value = [
            $frm_data['name'],
            $frm_data['phone'],          // Corresponds to phone
            $frm_data['email'],          // Corresponds to email
            $frm_data['destinations'],   // Corresponds to destinations
            $frm_data['travelDates'],    // Corresponds to travel_dates
            $frm_data['budget'],         // Corresponds to budget
            isset($frm_data['message']) ? $frm_data['message'] : '' // Corresponds to message (optional)
        ];

        // Execute the query using the insert function
        $res = insert($q, $value, 'sssssss'); // 'sssssss' indicates 7 string parameters

        // Check the result and respond accordingly
        if ($res == 1) {
            alert('success', 'Your custom package request has been submitted successfully!');
            echo '<script>window.location = "packages.php";</script>';
            exit();
        } else {
            alert('error', 'Server Down! Please try again later.');
        }
    }
    ?>

</body>

</html>