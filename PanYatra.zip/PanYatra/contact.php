<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PANYATRA - contact us</title>
  <?php require('inc/link.php'); ?>


</head>

<body class="bg-light">

  <!-- Header Section -->
  <?php require('inc/header.php'); ?>

  <!-- Facilities Section -->
  <div class="my-5 px-4">
    <h2 class="fw-bold h-font text-center">Contact US</h2>
    <div class="h-line bg-dark"></div>
    <p class="text-center mt-3">
      Lorem ipsum dolor sit amet, consectetur adipisicing elit.
      Quas, pariatur ipsa.<br> Eius minima aperiam nesciunt,
      minus ea cumque nostrum consectetur!
    </p>
  </div>

<?php 
   $contact_q = "SELECT * FROM `contact_details` WHERE `sr_no`=?";
      $values =[1];
    $contact_r = mysqli_fetch_assoc(select($contact_q,$values,'i'));
?>

  <!-- Facilities Cards Section -->
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-md-6 mb-5 px-4">
        <div class="bg-white rounded shadow p-4">
          <iframe class="w-100 rounded mb-4" height="320px" src="<?php echo $contact_r['iframe'] ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
          <h5 class="mt-4">Address</h5>
          <a href="<?php echo $contact_r['g-map'] ?>" target="_blank" class="d-inline-block text-decoration-none text-dark mb-2">
            <i class="bi bi-geo-alt-fill"></i> <?php echo $contact_r['address'] ?>
          </a>
          <h5 class="text-dark">Call us</h5>
          <a href="tel:+<?php echo $contact_r['pn1'] ?>" class="d-inline-block m-2 mb-2 mb-0 text-decoration-none text-dark">
            <i class="bi bi-telephone-outbound-fill me-1"></i> +<?php echo $contact_r['pn1'] ?>
          </a>
          <br>
          <a href="tel:+<?php echo $contact_r['pn2'] ?>" class="d-inline-block m-2 mb-0 text-decoration-none text-dark">
            <i class="bi bi-telephone-outbound-fill me-1"></i> +<?php echo $contact_r['pn2'] ?>
          </a>

          <h5 class="mt-4">EMAIL</h5>
          <a href="mailto: <?php echo $contact_r['email'] ?>" class="d-inline-block m-2 mb-0 text-decoration-none text-dark">
            <i class="bi bi-envelope-at-fill me-1"></i> <?php echo $contact_r['email'] ?>
          </a>

          <h5 class="mt-4 text-dark">Follow Us</h5>
          <a href="<?php echo $contact_r['tw'] ?>" class="d-inline-block fs-6 text-dark mb-3 me-2">
            <i class="bi bi-twitter-x me-1"></i>
          </a>

          <a href="<?php echo $contact_r['insta'] ?>" class="d-inline-block fs-6 text-dark mb-3 me-2">
            <i class="bi bi-instagram me-1"></i>
          </a>

          <a href="<?php echo $contact_r['fb'] ?>" class="d-inline-block fs-6 text-dark mb-3 me-2">
            <i class="bi bi-facebook me-1"></i>
          </a>
        </div>
      </div>

      <div class="col-lg-6 col-md-6 px-4">
        <div class="bg-white rounded shadow p-4 ">
          <form method="POST">
            <h5>Send a message</h5>
            <div class="mt3-3">
              <label class="form-label" style="font-weight:500">Name</label>
              <input name="name" required type="text" class="form-control shadow-none">
            </div>
            <div class="mt3-3">
              <label class="form-label" style="font-weight:500">Email</label>
              <input name="email" required type="email" class="form-control shadow-none">
            </div>
            <div class="mt3-3">
              <label class="form-label" style="font-weight:500">Phone</label>
              <input name="phone" required type="text" class="form-control shadow-none">
            </div>
            <div class="mt3-3">
              <label class="form-label" style="font-weight:500">Subject</label>
              <input name="subject" required type="text" class="form-control shadow-none">
            </div>
            <div class="mt3-3">
              <label class="form-label" style="font-weight:500">Message</label>
              <textarea name="message" required class="form-control shadow-none" rows="5" style="resize: none"></textarea>
            </div>
            <button type="submit" name="send" class="btn text-white custom-bg mt-3">Send</button>
          </form>
        </div>
      </div>

      <?php
      if (isset($_POST['send'])) {
        $frm_data = filteration($_POST);

        $q = "INSERT INTO `data_quries`( `name`, `email`, `phone`, `subject`, `message`) VALUES (?,?,?,?,?)";
        $value = [$frm_data['name'], $frm_data['email'], $frm_data['phone'], $frm_data['subject'], $frm_data['message']];

        $res = insert($q, $value, 'sssss');
        if ($res == 1) {
          alert('success', 'Message sent! Thanks for connecting us');
          echo '<script>window.location = "contact.php";</script>';
          exit();
        } else {
          alert('error', 'Server Down! Please try again leter.');
        }
      }


      ?>

      <!-- Footer Section -->
      <?php require('inc/footer.php'); ?>

      <!-- JavaScript and Swiper Bundle -->
      <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
      <!-- Add your custom scripts here -->



</body>

</html>