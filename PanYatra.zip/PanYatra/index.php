<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PANYATRA - Travel companies</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <?php require('inc/link.php'); ?>


    <style>
        .swiper-testimonials {
            margin-top: 30px;
        }

        .swiper-slide {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 15px;
            width: 250px;
            margin: 0 10px;
        }

        .profile {
            display: flex;
            align-items: center;
        }

        .profile img {
            object-fit: cover;
            border-radius: 50%;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            width: 80px;
            /* Set a smaller width for the image */
            height: 80px;
        }

        .profile h6 {
            font-size: 1.1rem;
            color: #333;
        }

        .profile p {
            font-size: 0.9rem;
            color: #777;
            line-height: 1.4;
        }

        .rating i {
            font-size: 1.2rem;
        }

        .swiper-slide .rating {
            margin-top: 10px;
        }

        .swiper-pagination {
            bottom: 10px !important;
            z-index: 10;
        }

        /* Responsive Styling */
        @media (max-width: 767px) {
            .swiper-slide {
                width: 200px;
                /* Adjust card width for smaller screens */
                padding: 10px;
            }

            .profile img {
                width: 70px;
                height: 70px;
            }

            .profile h6 {
                font-size: 1rem;
            }

            .profile p {
                font-size: 0.85rem;
            }
        }

        @media (max-width: 575px) {
            .swiper-slide {
                width: 180px;
                /* Adjust card width for even smaller screens */
                padding: 15px;
            }

            .profile img {
                width: 60px;
                height: 60px;
            }

            .profile h6 {
                font-size: 1rem;
            }

            .profile p {
                font-size: 0.8rem;
            }
        }

        /* To make the images in the carousel smaller */
        .swiper-slide img.img-sm {
            height: 600px;
            /* Adjust the height as per your requirement */
            object-fit: cover;
            /* Ensures the image covers the area while maintaining aspect ratio */
        }

        /* Adjust the text content positioning */
        .swiper-slide .content {
            max-width: 80%;
            /* Adjust the width of the text container */
            padding: 20px;
        }

        .swiper-slide .content h2 {
            font-size: 2rem;
            color: #000;
            /* Adjusts the font size for smaller screens */
        }

        .swiper-slide .content p {
            font-size: 1.25rem;
            color: #000;
            /* Adjusts the font size for smaller screens */
        }

        /* Ensure text stays inside the image on smaller screens */
        @media (max-width: 768px) {
            .swiper-slide .content {
                max-width: 90%;
                /* Ensure content adjusts to smaller screens */
            }

            .swiper-slide .content h2 {
                font-size: 1.5rem;
            }

            .swiper-slide .content p {
                font-size: 1rem;
            }
        }

        /*form */
        .availability-form {
            margin-top: -50px;
            z-index: 2;
            position: relative;
            opacity: 0.95;
            background-color: #E0F7FA;
            /* Soft light blue background for a calming effect */
            border-radius: 15px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            /* Soft shadow for depth */
            transition: box-shadow 0.3s ease;
        }

        .availability-form:hover {
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.2);
            /* Hover effect for stronger shadow */
        }

        .availability-form .row {
            display: flex;
            justify-content: center;
        }

        availability-form .form-control {
            height: 30px;
            /* Adjust input height */
            font-size: 14px;
        }

        .form-control {
            border: 1px solid #ccc;
            border-radius: 10px;
            transition: all 0.3s ease;
            /* Smooth transition for all properties */
            background-color: #fff;
            /* Light background for inputs */
        }

        .form-control:focus {
            border-color: #ffaa16;
            box-shadow: 0 0 5px rgba(255, 170, 22, 0.5);
        }

        .btn.custom-bg {
            background-color: #ffaa16;
            border-radius: 10px;
            height: auto;
            /* Increased padding for better clickability */
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        }

        .btn.custom-bg:hover {
            transform: translateY(-2px);
            /* Smooth up animation */
            box-shadow: 0 5px 10px rgba(255, 170, 22, 0.3);
            /* Soft shadow on hover */
        }

        @media screen and (max-width: 575px) {
            .availability-form {
                margin-top: 25px;
                padding: 0 35px;
            }

            .btn.custom-bg {
                padding: 10px 20px;
                /* Adjust button size for smaller screens */
            }
        }


        /*Inspired for Your Next Trip */
        .inspiration-section {
            text-align: center;
            margin-bottom: 40px;
        }

        .inspiration-cards {
            display: flex;
            gap: 35px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .card {
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            width: 400px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card img {
            width: 100%;
            height: 250px;
            /* Increase height for a larger image */
            object-fit: cover;
        }

        .card-content {
            padding: 15px;
        }

        .card-content h3 {
            font-size: 1.3em;
            margin: 10px 0;
        }

        .card-content .location {
            color: #666;
            font-size: 0.9em;
        }

        .card-content .rating {
            color: #ffaa16;
            font-size: 1.1em;
        }

        .card-content .price {
            font-size: 1em;
            color: #000;
            margin: 10px 0;
        }

        .card-content .price .old-price {
            text-decoration: line-through;
            color: #888;
            margin-right: 5px;
        }

        .card-content .duration {
            font-size: 0.9em;
            color: #666;
        }

        /* Media query to make cards responsive */
        @media (max-width: 1200px) {
            .card {
                width: 300px;
            }
        }

        @media (max-width: 900px) {
            .card {
                width: 300px;
            }
        }

        @media (max-width: 600px) {
            .card {
                width: 300px;
            }
        }

        /* Base Styles */
        h5.dash-style {
            color: #FF5A5F;
            font-size: 18px;
            letter-spacing: 2px;
            text-transform: uppercase;
            margin-bottom: 20px;
            text-align: center;
        }

        h2.portfolio {
            text-align: center;
            font-weight: bold;
            font-size: 28px;
            color: #333;
        }

        /*recommadation*/
        .recommended-section {
            padding: 50px 0;
            background-color: #f9f9f9;
        }

        .section-title {
            text-align: center;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .services-item {
            border-radius: 8px;
            overflow: hidden;
            background-color: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .service-border {
            position: relative;
            padding: 15px;
        }

        .featured-image {
            position: relative;
        }

        .image-feature {
            width: 100%;
            height: auto;
            border-radius: 8px;
        }

        .st-tag-feature-sale {
            position: absolute;
            top: 10px;
            left: 10px;
            display: flex;
            gap: 5px;
            font-size: 12px;
            color: #fff;
        }

        .featured {
            background-color: #ff4a4a;
            padding: 5px 10px;
            border-radius: 5px;
        }

        .st_sale_class {
            background-color: #232323;
            padding: 5px;
            border-radius: 5px;
        }

        .service-avatar {
            position: absolute;
            bottom: -15px;
            right: 10px;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            overflow: hidden;
        }

        .avatar {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .content-item {
            padding-top: 20px;
        }

        .sub-title {
            color: #888;
            font-size: 14px;
        }

        .title {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            margin-top: 5px;
            margin-bottom: 10px;
        }

        .reviews {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 14px;
            color: #ffbb00;
        }

        .price-info {
            display: flex;
            justify-content: space-between;
            font-size: 14px;
            margin-top: 10px;
        }

        .onsale {
            text-decoration: line-through;
            color: #999;
        }

        .duration {
            color: #888;
        }

        /* Swiper Styles */
        .swiper-container {
            padding: 20px 0;
        }

        .swiper-slide1 {
            width: auto;
            max-width: 300px;
        }

        /* Responsive Styling */
        @media (max-width: 768px) {
            .swiper-slide1 {
                max-width: 100%;
            }
        }
        @media (max-width: 320px) {
            .swiper-slide1 {
                max-width: 90%;
            }
        }

        /*circular crausol*/
        .custom-card {
            width: 250px;
            height: 250px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            margin: auto;
            background: transparent;
            /* No background color */
            border: none;
            /* Remove any border if present */
            box-shadow: none;
            /* Remove shadow for a "no-background" look */
        }

        .custom-card img {
            object-fit: cover;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            /* Make the image circular */
            transition: transform 0.3s ease;
            /* Add scaling effect to image */
        }

        .custom-card:hover img {
            transform: scale(1.05);
            /* Slightly zoom the image on hover */
        }

        /* For smaller screens */
        @media (max-width: 576px) {
            .custom-card {
                width: 180px;
                height: 180px;
            }
        }

        /* For medium screens */
        @media (min-width: 577px) and (max-width: 992px) {
            .custom-card {
                width: 220px;
                height: 220px;
            }
        }

        /* For large screens */
        @media (min-width: 993px) {
            .custom-card {
                width: 250px;
                height: 250px;
            }
        }

        .text-center {
            margin-top: 10px;
            /* Ensure spacing below image */
        }

        /*Why chosse us */
        #why-choose-us {
            background-color: #f8f9fa;
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: #2c3e50;
        }

        .lead {
            font-size: 1.2rem;
            color: #7f8c8d;
        }

        .card {
            transition: transform 0.3s ease-in-out;
        }

        .card:hover {
            transform: translateY(-10px);
        }

        .card-img-top {
            height: 250px;
            object-fit: cover;
        }

        .card-title {
            font-size: 1.3rem;
            font-weight: bold;
            color: #2980b9;
        }

        .card-text {
            color: #7f8c8d;
        }

        .btn-primary {
            background-color: #2980b9;
            color: white;
            border-radius: 30px;
            font-weight: bold;
        }

        .btn-primary:hover {
            background-color: #3498db;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .section-title {
                font-size: 2rem;
            }

            .card-title {
                font-size: 1.1rem;
            }

            .lead {
                font-size: 1rem;
            }
        }

        /*guide Tour */
        #guided-tours {
            background-color: #f8f9fa;
        }

        .card-title {
            font-size: 1.75rem;
            font-weight: bold;
            color: #333;
        }

        .card-body {
            padding: 15px;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body class="bg-light">


    <?php require('inc/header.php'); ?>


    <!-- home  -->
    <div class="container-fluid px-lg-3 mt-3">
        <div class="swiper home-slide">
            <div class="swiper-wrapper">
                <?php
                $res = selectAll('carousel');
                while ($row = mysqli_fetch_assoc($res)) {

                    $path = CAROUSEL_IMG_PATH;
                    echo <<< data
                    <div class="swiper-slide">
                        <div class="w-100 d-block">
                            <img src="$path$row[image]" alt="image" class="w-100 d-block img-sm">
                        </div>
                        <div class="content text-center text-warning fw-bold position-absolute top-50 start-50 translate-middle">
                            <h2 class="h-font">Embark on your dream journey with us.</h2>
                            <p class="h-font">Explore the world, discover new places, and create unforgettable memories.</p>
                        </div>
                    </div>
                data;
                }
                ?>
            </div>
        </div>
    </div>


    <!-- Check Booking Availability form -->
    <div class="container availability-form" style="border-radius:10rem;">
        <div class="row">
            <div class="col-lg-12 p-4 shadow-lg" style="border-radius:10rem;">
                <h5 class="mt-2 mb-4 text-center fw-bold h-font">Check Your Trip Availability</h5>
                <form>
                    <div class="row align-items-end">
                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight: 500;">From (Location)</label>
                            <input type="text" class="form-control shadow-none" placeholder="Enter departure city">
                        </div>
                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight: 500;">To (Destination)</label>
                            <input type="text" class="form-control shadow-none" placeholder="Enter destination city">
                        </div>
                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight: 500;">Choose Vehicle</label>
                            <input type="text" class="form-control shadow-none" placeholder="e.g., Sedan, SUV, etc.">
                        </div>
                        <div class="col-lg-2 mb-3">
                            <label class="form-label" style="font-weight: 500;">Travel Date</label>
                            <input type="date" class="form-control shadow-none">
                        </div>
                    </div>
                    <!-- Centering the button below the form -->
                    <div class="row justify-content-center">
                        <div class="col-12 text-center">
                            <button type="button" class="btn text-white shadow-none custom-bg" onclick="changeColor()">Check Availability</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>



    <!-- services -->
    <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">Services</h2>
    <div class="container">
        <div class="row">
            <!-- Transport Service Card -->
            <div class="col-lg-4 col-md-6 my-3">
                <div class="card border-0 shadow" style="max-width: 350px; margin: auto; background-color: #f0f8ff;">
                    <img src="image/hotel/1.jpg" class="card-img-top" alt="Transport Service" style="width: 100%; border-radius: 5px 5px 0 0;">
                    <div class="card-body text-center">
                        <h5 class="card-title h-font text-primary">Transport Service</h5>
                        <div class="feature mb-3">
                            <h6 class="mb-1 text-dark">Feature</h6>
                            <span class="badge rounded-pill bg-light text-dark">Reliable</span>
                            <span class="badge rounded-pill bg-light text-dark">Fast</span>
                            <span class="badge rounded-pill bg-light text-dark">Affordable</span>
                        </div>
                        <div class="rating mb-3">
                            <h6 class="mb-1 text-dark">Rating</h6>
                            <span class="badge rounded-pill bg-light">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                            </span>
                        </div>
                        <div class="d-flex justify-content-center mb-3">
                            <a href="cabs.php" class="btn btn-sm text-white" style="background-color: #1e3a8a;">Book Now</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Package Card -->
            <div class="col-lg-4 col-md-6 my-3">
                <div class="card border-0 shadow" style="max-width: 350px; margin: auto; background-color: #f0f8ff;">
                    <img src="image/hotel/2.avif" class="card-img-top" alt="Package" style="width: 100%; border-radius: 5px 5px 0 0;">
                    <div class="card-body text-center">
                        <h5 class="card-title h-font text-primary">Package</h5>
                        <div class="feature mb-3">
                            <h6 class="mb-1 text-dark">Feature</h6>
                            <span class="badge rounded-pill bg-light text-dark">Secure</span>
                            <span class="badge rounded-pill bg-light text-dark">Trackable</span>
                            <span class="badge rounded-pill bg-light text-dark">Eco-friendly</span>
                        </div>
                        <div class="rating mb-3">
                            <h6 class="mb-1 text-dark">Rating</h6>
                            <span class="badge rounded-pill bg-light">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-half text-warning"></i>
                            </span>
                        </div>
                        <div class="d-flex justify-content-center mb-3">
                            <a href="packages.php" class="btn btn-sm text-white" style="background-color: #1e3a8a;">Get Quote</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Hotel Card -->
            <div class="col-lg-4 col-md-6 my-3">
                <div class="card border-0 shadow" style="max-width: 350px; margin: auto; background-color: #f0f8ff;">
                    <img src="image/hotel/3.avif" class="card-img-top" alt="Hotel" style="width: 100%; border-radius: 5px 5px 0 0;">
                    <div class="card-body text-center">
                        <h5 class="card-title h-font text-primary">Hotel</h5>

                        <!-- Features Section -->
                        <div class="feature mb-3">
                            <h6 class="mb-1 text-dark">Features</h6>
                            <span class="badge rounded-pill bg-light text-dark">Comfort</span>
                            <span class="badge rounded-pill bg-light text-dark">Luxury</span>
                            <span class="badge rounded-pill bg-light text-dark">Affordable</span>
                        </div>

                        <!-- Rating Section -->
                        <div class="rating mb-3">
                            <h6 class="mb-1 text-dark">Rating</h6>
                            <span class="badge rounded-pill bg-light">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star text-warning"></i>
                            </span>
                        </div>

                        <!-- Booking Button -->
                        <div class="d-flex justify-content-center mb-3">
                            <a href="hotel.php" class="btn btn-sm text-white" style="background-color: #1e3a8a;">Book Room</a>
                        </div>
                    </div>
                </div>
            </div>


            <!-- Know More Button -->
            <div class="col-lg-12 text-center mt-5">
                <a href="#" class="btn btn-sm btn-warning text-white">Know More &gt;&gt;&gt;</a>
            </div>
        </div>
    </div>


    <!-- Swiper Container -->
    <!-- Swiper Container -->
    <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">More Loaction</h2>
    <div class="container-fluid py-5">
        <div class="swiper mySwiper">
            <div class="swiper-wrapper">
                <?php
                // Fetch all locations from the database
                $location_r = selectAll('location');
                $path = LOCATION_IMG_PATH; // Define the base path for images

                // Loop through each location and display it as a swiper slide
                while ($row = mysqli_fetch_assoc($location_r)) {
                    echo <<<HTML
                <div class="swiper-slide">
                    <div class="card custom-card text-center">
                        <div class="rounded-circle mx-auto overflow-hidden" style="width: 150px; height: 150px;">
                            <img src="{$path}{$row['image']}" class="w-100 h-100" alt="Location Image" style="object-fit: cover;">
                        </div>
                        <div class="mt-3">
                            <h5 class="card-title">{$row['location_name']}</h5>
                            <p class="card-text">{$row['location_desc']}</p>
                        </div>
                    </div>
                </div>
                HTML;
                }
                ?>
            </div>

        </div>
    </div>






    <!-- portfolio -->
    <h2 class="portfolio mt-5 pt-4 mb-4 text-center fw-bold h-font" id="portfolio">Portfolio</h2>
    <section class="services" id="services">
        <div class="row">
            <!-- Transportation Service -->
            <div class="transportation col-lg-3 col-md-6 my-3" id="transportio">
                <div class="box">
                    <h3>Transportation</h3>
                    <p>Our reliable transportation service ensures smooth travel experiences, offering everything from airport transfers to private tours. Whether by air, road, or sea, we guarantee comfort, safety, and punctuality on your journey.</p>
                </div>
            </div>

            <!-- Tour Packages Service -->
            <div class="tour-packages col-lg-3 col-md-6 my-3" id="tour-packages">
                <div class="box">
                    <h3>Tour Packages</h3>
                    <p>Explore the world with our tailor-made tour packages. From relaxing beach holidays to adventurous mountain treks, we offer diverse options to suit every traveler's dream.</p>
                </div>
            </div>

            <!-- Accommodation Service -->
            <div class="accommodation col-lg-3 col-md-6 my-3" id="accommodation">
                <div class="box">
                    <h3>Accommodation</h3>
                    <p>Experience comfort and luxury with our exclusive hotel and resort partnerships. Whether you prefer a cozy hotel in the city center or a luxurious resort by the beach, we ensure quality and convenience at affordable rates.</p>
                </div>
            </div>

            <!-- Event Management Service -->
            <div class="event-management col-lg-3 col-md-6 my-3" id="event-management">
                <div class="box">
                    <h3>Event Management</h3>
                    <p>We specialize in organizing corporate events, destination weddings, and other special gatherings. Let us take care of all the details, so you can focus on making unforgettable memories.</p>
                </div>
            </div>
        </div>
    </section>


    <!--trip-->
    <h5 class="dash-style" style="color: #FF5A5F; font-size: 18px; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 10px;">TRAVEL BY ACTIVITY</h5>
    <h2 class=" portfolio mt-5 pt-4 mb-4 text-center fw-bold h-font" id="portfolio">Get Inspired for Your Next Trip</h2>
    <div class="inspiration-section">
        <div class="inspiration-cards">
            <!-- Card 1 -->
            <?php
            // Assuming `selectAll()` fetches all records from the 'team_details' table
            $destination_r = selectAll('destinations');
            $path = LATEST_IMG_PATH; // Define the base path for images

            while ($row = mysqli_fetch_assoc($destination_r)) {
                echo <<<HTML
                        <div class="inspiration-section">
                            <div class="card">
                                <img src="{$path}{$row['location_image']}" class="card-img-top" >
                                <div class="card-body">
                                    <p class="location">📍{$row['location']}</p>
                                    <h3>{$row['description']}</h3> 
                                    <p class="price"><span class="old-price" style="text-decoration: line-through;">${row['old_price']}</span> From <strong> ${row['new_price']}</strong></p>
                                    <p class="text-muted"><i class="bi bi-clock"></i>{$row['duration']}</p>
                                </div>
                            </div>
                        </div>
                  HTML;
            }
            ?>
        </div>
    </div>

    <!--recomandation section-->


    <!--advanture-->
    <section class="activity-section" style="padding: 50px 0; background-color: #f9f9f9;">
        <div class="container" style="max-width: 1200px; margin: 0 auto;">
            <div class="section-heading text-center" style="margin-bottom: 40px;">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h5 class="dash-style" style="color: #FF5A5F; font-size: 18px; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 10px;">TRAVEL BY ACTIVITY</h5>
                        <h2 style="font-size: 32px; font-weight: bold; color: #333; margin-bottom: 20px;">ADVENTURE &amp; ACTIVITY</h2>
                        <p style="color: #666; font-size: 16px; line-height: 1.6;">Mollit voluptatem perspiciatis convallis elementum corporis quo veritatis aliquid blandit, blandit torquent, odit placeat. Adipiscing repudiandae eius cursus? Nostrum magnis maxime curae placeat.</p>
                    </div>
                </div>
            </div>
            <div class="activity-inner row" style="display: flex; justify-content: space-around; flex-wrap: wrap;">
                <div class="col-lg-2 col-md-4 col-sm-6" style="padding: 15px; box-sizing: border-box;">
                    <div class="activity-item" style="background-color: #fff; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); text-align: center; padding: 20px;">
                        <div class="activity-icon" style="margin-bottom: 15px;">
                            <a href="#">
                                <img src="image/icon/treak.png" alt="" style="width: 50px; height: 50px;">
                            </a>
                        </div>
                        <div class="activity-content">
                            <h4 style="font-size: 18px; color: #333; margin-bottom: 5px;">
                                <a href="#" style="color: #333; text-decoration: none;">Adventure</a>
                            </h4>
                            <p style="color: #666; font-size: 14px;">15 Destination</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6" style="padding: 15px; box-sizing: border-box;">
                    <div class="activity-item" style="background-color: #fff; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); text-align: center; padding: 20px;">
                        <div class="activity-icon" style="margin-bottom: 15px;">
                            <a href="#">
                                <img src="image/icon/track.png" alt="" style="width: 50px; height: 50px;">
                            </a>
                        </div>
                        <div class="activity-content">
                            <h4 style="font-size: 18px; color: #333; margin-bottom: 5px;">
                                <a href="#" style="color: #333; text-decoration: none;">Trekking</a>
                            </h4>
                            <p style="color: #666; font-size: 14px;">12 Destination</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6" style="padding: 15px; box-sizing: border-box;">
                    <div class="activity-item" style="background-color: #fff; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); text-align: center; padding: 20px;">
                        <div class="activity-icon" style="margin-bottom: 15px;">
                            <a href="#">
                                <img src="image/icon/camp.png" alt="" style="width: 50px; height: 50px;">
                            </a>
                        </div>
                        <div class="activity-content">
                            <h4 style="font-size: 18px; color: #333; margin-bottom: 5px;">
                                <a href="#" style="color: #333; text-decoration: none;">Camp Fire</a>
                            </h4>
                            <p style="color: #666; font-size: 14px;">7 Destination</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6" style="padding: 15px; box-sizing: border-box;">
                    <div class="activity-item" style="background-color: #fff; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); text-align: center; padding: 20px;">
                        <div class="activity-icon" style="margin-bottom: 15px;">
                            <a href="#">
                                <img src="image/icon/ofroad.png" alt="" style="width: 50px; height: 50px;">
                            </a>
                        </div>
                        <div class="activity-content">
                            <h4 style="font-size: 18px; color: #333; margin-bottom: 5px;">
                                <a href="#" style="color: #333; text-decoration: none;">Off Road</a>
                            </h4>
                            <p style="color: #666; font-size: 14px;">15 Destination</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6" style="padding: 15px; box-sizing: border-box;">
                    <div class="activity-item" style="background-color: #fff; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); text-align: center; padding: 20px;">
                        <div class="activity-icon" style="margin-bottom: 15px;">
                            <a href="#">
                                <img src="image/icon/fire.png" alt="" style="width: 50px; height: 50px;">
                            </a>
                        </div>
                        <div class="activity-content">
                            <h4 style="font-size: 18px; color: #333; margin-bottom: 5px;">
                                <a href="#" style="color: #333; text-decoration: none;">Camping</a>
                            </h4>
                            <p style="color: #666; font-size: 14px;">13 Destination</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6" style="padding: 15px; box-sizing: border-box;">
                    <div class="activity-item" style="background-color: #fff; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); text-align: center; padding: 20px;">
                        <div class="activity-icon" style="margin-bottom: 15px;">
                            <a href="#">
                                <img src="image/icon/adventurer.png" alt="" style="width: 50px; height: 50px;">
                            </a>
                        </div>
                        <div class="activity-content">
                            <h4 style="font-size: 18px; color: #333; margin-bottom: 5px;">
                                <a href="#" style="color: #333; text-decoration: none;">Exploring</a>
                            </h4>
                            <p style="color: #666; font-size: 14px;">25 Destination</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- why chosse Panyatra? -->
    <section id="why-choose-us" class="py-5 bg-light">
        <div class="container">
            <div class="row text-center">
                <div class="col-12">
                    <h2 class="section-title mb-4">Why Choose Panyatra?</h2>
                    <p class="lead mb-5">Experience the World Like Never Before with Our Exclusive Travel Services</p>
                </div>
            </div>
            <div class="row text-center">
                <!-- Card 1 -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm border-0 rounded">
                        <img src="image/hotel/a1.jpg" class="card-img-top" alt="Affordable Travel">
                        <div class="card-body">
                            <h5 class="card-title">Affordable Packages</h5>
                            <p class="card-text">Get the best deals on travel packages without compromising on quality. We offer options for every budget.</p>
                        </div>
                    </div>
                </div>
                <!-- Card 2 -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm border-0 rounded">
                        <img src="image/hotel/w1.webp" class="card-img-top" alt="Expert Guidance">
                        <div class="card-body">
                            <h5 class="card-title">Expert Guidance</h5>
                            <p class="card-text">Our team of travel experts ensures that you receive the best advice and recommendations for your journey.</p>
                        </div>
                    </div>
                </div>
                <!-- Card 3 -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm border-0 rounded">
                        <img src="image/hotel/w2.webp" class="card-img-top" alt="Safe & Secure">
                        <div class="card-body">
                            <h5 class="card-title">Safe & Secure</h5>
                            <p class="card-text">Your safety is our priority. We ensure secure bookings, transparent pricing, and reliable travel insurance.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row text-center">
                <div class="col-12">
                    <a href="packages.php" class="btn btn-warning px-4 py-2 mt-3">Browse Our Packages</a>
                </div>
            </div>
        </div>
    </section>

    <!-- guide tour -->
    <section id="guided-tours" class="py-5 bg-light">
        <div class="container text-center">
            <h2 class="section-title mb-4">Guided Tours</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card custom-card">
                        <img src="image/hote16.jpg" class="card-img-top" alt="tour image">
                        <div class="card-body">
                            <h5 class="card-title">Historic City Tour</h5>
                            <p class="card-text">Explore the rich history of a city with knowledgeable guides who provide fascinating stories and landmarks.</p>
                            <a href="tour-details1.html" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card custom-card">
                        <img src="tour-image2.jpg" class="card-img-top" alt="tour image">
                        <div class="card-body">
                            <h5 class="card-title">Nature and Wildlife Tour</h5>
                            <p class="card-text">Discover the natural beauty and wildlife of a region with an expert guide.</p>

                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card custom-card">
                        <img src="tour-image3.jpg" class="card-img-top" alt="tour image">
                        <div class="card-body">
                            <h5 class="card-title">Culinary Experience Tour</h5>
                            <p class="card-text">Enjoy a hands-on cooking experience with traditional recipes and culinary delights.</p>
                            <a href="tour-details3.html" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>
                <div class="row text-center">
                    <div class="col-12">
                        <a href="packages.php" class="btn btn-warning px-4 py-2 mt-3">View Details</a>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Testimonials   -->
    <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">Testimonials</h2>
    <div class="container mt-5">
        <div class="swiper swiper-testimonials">
            <div class="swiper-wrapper mb-5">

                <!-- Testimonial 1 -->
                <div class="swiper-slide bg-white p-4 rounded shadow-sm">
                    <div class="profile d-flex align-items-center mb-3">
                        <img src="image/prj3.jpg" width="100px" height="100px" class="rounded-circle" alt="user">
                        <div class="ms-3">
                            <h6 class="m-0 fw-bold">Random User</h6>
                            <p class="text-muted">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus quod quibusdam accusamus.</p>
                            <div class="rating">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Testimonial 2 -->
                <div class="swiper-slide bg-white p-4 rounded shadow-sm">
                    <div class="profile d-flex align-items-center mb-3">
                        <img src="image/prj5.jpg" width="100px" height="100px" class="rounded-circle" alt="user">
                        <div class="ms-3">
                            <h6 class="m-0 fw-bold">Random User</h6>
                            <p class="text-muted">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus quod quibusdam accusamus.</p>
                            <div class="rating">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Testimonial 3 -->
                <div class="swiper-slide bg-white p-4 rounded shadow-sm">
                    <div class="profile d-flex align-items-center mb-3">
                        <img src="image/prj4.jpg" width="100px" height="100px" class="rounded-circle" alt="user">
                        <div class="ms-3">
                            <h6 class="m-0 fw-bold">Random User</h6>
                            <p class="text-muted">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus quod quibusdam accusamus.</p>
                            <div class="rating">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="swiper-slide bg-white p-4 rounded shadow-sm">
                    <div class="profile d-flex align-items-center mb-3">
                        <img src="image/prj4.jpg" width="100px" height="100px" class="rounded-circle" alt="user">
                        <div class="ms-3">
                            <h6 class="m-0 fw-bold">Random User</h6>
                            <p class="text-muted">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus quod quibusdam accusamus.</p>
                            <div class="rating">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="swiper-slide bg-white p-4 rounded shadow-sm">
                    <div class="profile d-flex align-items-center mb-3">
                        <img src="image/prj4.jpg" width="100px" height="100px" class="rounded-circle" alt="user">
                        <div class="ms-3">
                            <h6 class="m-0 fw-bold">Random User</h6>
                            <p class="text-muted">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus quod quibusdam accusamus.</p>
                            <div class="rating">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="swiper-slide bg-white p-4 rounded shadow-sm">
                    <div class="profile d-flex align-items-center mb-3">
                        <img src="image/prj4.jpg" width="100px" height="100px" class="rounded-circle" alt="user">
                        <div class="ms-3">
                            <h6 class="m-0 fw-bold">Random User</h6>
                            <p class="text-muted">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus quod quibusdam accusamus.</p>
                            <div class="rating">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="swiper-slide bg-white p-4 rounded shadow-sm">
                    <div class="profile d-flex align-items-center mb-3">
                        <img src="image/prj4.jpg" width="100px" height="100px" class="rounded-circle" alt="user">
                        <div class="ms-3">
                            <h6 class="m-0 fw-bold">Random User</h6>
                            <p class="text-muted">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus quod quibusdam accusamus.</p>
                            <div class="rating">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="swiper-slide bg-white p-4 rounded shadow-sm">
                    <div class="profile d-flex align-items-center mb-3">
                        <img src="image/prj4.jpg" width="100px" height="100px" class="rounded-circle" alt="user">
                        <div class="ms-3">
                            <h6 class="m-0 fw-bold">Random User</h6>
                            <p class="text-muted">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus quod quibusdam accusamus.</p>
                            <div class="rating">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="swiper-slide bg-white p-4 rounded shadow-sm">
                    <div class="profile d-flex align-items-center mb-3">
                        <img src="image/prj4.jpg" width="100px" height="100px" class="rounded-circle" alt="user">
                        <div class="ms-3">
                            <h6 class="m-0 fw-bold">Random User</h6>
                            <p class="text-muted">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus quod quibusdam accusamus.</p>
                            <div class="rating">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- Pagination -->
            <div class="swiper-pagination"></div>
        </div>
    </div>


    <!-- Reach-Us -->

    <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">Reach Us</h2>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 p-4 mb-lg-0 mb-3 bg-white rounded">
                <iframe class="w-100" height="400px" src="<?Php echo $contact_r['iframe'] ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

            </div>
            <div class="col-lg-4 col-md-8">
                <div class="bg-white rounded mb-4 text-center">
                    <h5 class="m-2 text-info">Call us</h5>
                    <a href="tel:+<?Php echo $contact_r['pn1'] ?>" class="d-inline-block m-2 mb-2 mb-0 text-decoration-none text-dark">
                        <i class="bi bi-telephone-outbound-fill me-1"></i> +<?Php echo $contact_r['pn1'] ?>
                    </a>
                    <br>
                    <a href="tel:+<?Php echo $contact_r['pn2'] ?>" class="d-inline-block m-2 mb-0 text-decoration-none text-dark">
                        <i class="bi bi-telephone-outbound-fill me-1"></i> +<?Php echo $contact_r['pn2'] ?>
                    </a>
                    <br><br>
                </div>

                <div class="bg-white text-center rounded mb-4">
                    <h5 class="m-2  text-info">Follow Us</h5>
                    <a href="<?php echo $contact_r['tw'] ?>" class="d-inline-block mb-1">
                        <span class="badge bg-light text-dark m-2 fs-6 p-2">
                            <i class="bi bi-twitter-x me-1"></i> Twitter
                        </span>
                    </a>
                    <br>

                    <a href="<?php echo $contact_r['insta'] ?>" class="d-inline-block mb-1">
                        <span class="badge bg-light text-dark m-2 fs-6 p-2">
                            <i class="bi bi-instagram me-1"></i> Instagram
                        </span>
                    </a>
                    <br>

                    <a href="<?php echo $contact_r['fb'] ?>" class="d-inline-block mb-1">
                        <span class="badge bg-light text-dark m-2 fs-6 p-2">
                            <i class="bi bi-facebook me-1"></i> Facebook
                        </span>
                    </a>
                    <br>

                    <a href="#" class="d-inline-block mb-1">
                        <span class="badge bg-light text-dark m-2 fs-6 p-2">
                            <i class="bi bi-whatsapp me-1"></i> Whatsapp
                        </span>
                    </a>
                    <br>

                    <a href="#" class="d-inline-block ">
                        <span class="badge bg-light text-dark m-2 fs-6 p-2">
                            <i class="bi bi-envelope-at-fill me-1"></i> Email
                        </span>
                    </a>
                </div>
            </div>

        </div>
    </div>

    <!-- footer -->
    <?php require('inc\footer.php'); ?>


    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Swiper for Home Slide
        var homeSlideSwiper = new Swiper(".home-slide", {
            pagination: {
                el: ".swiper-pagination",
                type: "fraction",
            },
            loop: true,
            autoplay: {
                delay: 4000,
            },
        });

        // Swiper for Testimonials
        var testimonialsSwiper = new Swiper(".swiper-testimonials", {
            effect: "coverflow",
            grabCursor: true,
            centeredSlides: true,
            slidesPerView: "auto", // Default behavior for dynamic slide sizes
            loop: true,
            coverflowEffect: {
                rotate: 40,
                stretch: 0,
                depth: 100,
                modifier: 1,
                slideShadows: false,
            },
            pagination: {
                el: ".swiper-pagination",
            },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                },
                640: {
                    slidesPerView: 1,
                },
                768: {
                    slidesPerView: 2,
                },
                1024: {
                    slidesPerView: 3,
                },
            }
        });

        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();

                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Swiper for Recommended Slider
        var recommendedSliderSwiper = new Swiper('.recommended-slider', {
            slidesPerView: 4,
            spaceBetween: 20,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            breakpoints: {
                1024: {
                    slidesPerView: 4,
                },
                768: {
                    slidesPerView: 2,
                },
                480: {
                    slidesPerView: 1,
                },
            },
        });

        // Swiper for MySwiper (Multiple cards with 1 to 4 views based on screen size)
        var mySwiper = new Swiper('.mySwiper', {
            slidesPerView: 3, // Default to 3 slides on large screens
            spaceBetween: 30, // Adjust space between the cards
            loop: true,
            centeredSlides: true,
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            breakpoints: {
                320: {
                    slidesPerView: 1, // Show 1 card on small screens
                },
                576: {
                    slidesPerView: 3, // Show 2 cards on medium screens
                },
                992: {
                    slidesPerView: 4, // Show 3 cards on larger screens
                },
                1200: {
                    slidesPerView: 5, // Show 4 cards on very large screens
                },
            },
        });
    </script>


</body>

</html>