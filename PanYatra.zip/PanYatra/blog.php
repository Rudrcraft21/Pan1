<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PANYATRA - Blog</title>
    <?php require('inc/link.php'); ?>
    <style>
        .blog-post {
            border-bottom: 1px solid #ddd;
            padding-bottom: 30px;
            margin-bottom: 30px;
        }

        .blog-post img {
            width: 100%;
            height: auto;
            border-radius: 10px;
        }

        .blog-title {
            font-size: 2rem;
            font-weight: bold;
            color: #333;
            margin-top: 15px;
        }

        .blog-meta {
            color: #777;
            font-size: 0.9rem;
        }

        .blog-excerpt {
            margin-top: 10px;
            font-size: 1.1rem;
            line-height: 1.6;
        }

        .comment-section {
            margin-top: 50px;
        }

        .comment-section h4 {
            font-size: 1.5rem;
            margin-bottom: 20px;
        }

        .comment-box {
            margin-bottom: 20px;
        }

        .comment-box textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            height: 150px;
        }

        .comment-box input[type="text"],
        .comment-box input[type="email"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            margin-bottom: 10px;
        }

        .comment-box button {
            background-color: #0d6efd;
            color: #fff;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .comment-box button:hover {
            background-color: #0056b3;
        }

        .social-share {
            margin-top: 30px;
            display: flex;
            gap: 10px;
        }

        .social-share button {
            background-color: #ddd;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
        }

        .social-share button:hover {
            background-color: #0d6efd;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 40px;
        }

        .pagination a {
            margin: 0 5px;
            padding: 8px 16px;
            border: 1px solid #ddd;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
        }

        .pagination a:hover {
            background-color: #0d6efd;
            color: #fff;
        }

        .pagination .active {
            background-color: #0d6efd;
            color: #fff;
        }
    </style>
</head>

<body class="bg-light">

    <!-- Header Section -->
    <?php require('inc/header.php'); ?>

    <!-- Blog Header -->
    <div class="my-5 px-4 text-center">
        <h2 class="fw-bold h-font">Our Blog</h2>
        <p>Read interesting articles, travel tips, and more about our cab services.</p>
        <div class="h-line bg-dark mx-auto"></div>
    </div>

    <!-- Blog Content Section -->
    <div class="container">
        <!-- Blog Post 1 -->
        <div class="blog-post">
            <img src="images/blog1.jpg" alt="blog-post-image">
            <h3 class="blog-title">Top 5 Tips for a Safe Cab Ride</h3>
            <div class="blog-meta">Posted on November 23, 2024 | By Admin</div>
            <p class="blog-excerpt">
                Ensuring a safe and comfortable ride should always be a priority. Here are the top five tips you should
                follow to ensure your safety while booking a cab...
            </p>
            <a href="blog-details.php" class="btn btn-primary">Read More</a>

            <!-- Social Sharing Buttons -->
            <div class="social-share">
                <button>Share on Facebook</button>
                <button>Share on Twitter</button>
                <button>Share on Instagram</button>
            </div>
        </div>

        <!-- Blog Post 2 -->
        <div class="blog-post">
            <img src="images/blog2.jpg" alt="blog-post-image">
            <h3 class="blog-title">Why Choose a Luxury Cab for Your Next Trip</h3>
            <div class="blog-meta">Posted on November 21, 2024 | By Admin</div>
            <p class="blog-excerpt">
                If you’re planning a special event or trip, you might want to choose a luxury cab for extra comfort and
                style. Learn why it's the best option...
            </p>
            <a href="blog-details.php" class="btn btn-primary">Read More</a>

            <!-- Social Sharing Buttons -->
            <div class="social-share">
                <button>Share on Facebook</button>
                <button>Share on Twitter</button>
                <button>Share on Instagram</button>
            </div>
        </div>

        <!-- Pagination -->
        <div class="pagination">
            <a href="#">1</a>
            <a href="#">2</a>
            <a href="#">3</a>
            <a href="#" class="active">Next &raquo;</a>
        </div>

        <!-- Comment Section -->
        <div class="comment-section">
            <h4>Leave a Comment</h4>
            <form action="#" method="POST" class="comment-box">
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <textarea name="comment" placeholder="Write your comment..." required></textarea>
                <button type="submit">Post Comment</button>
            </form>

            <div class="comments">
                <h5>John Doe:</h5>
                <p>Great tips for a safe ride. I always prefer using a trusted cab service!</p>
                <hr>
                <h5>Jane Smith:</h5>
                <p>I absolutely agree with the luxury cab idea. It's the perfect way to travel in style!</p>
            </div>
        </div>
    </div>

    <!-- Footer Section -->
    <?php require('inc/footer.php'); ?>

</body>

</html>
